# importing required modules
from tkinter import Tk


# creating basewindow class which creates a tk object
class Basewindow(Tk):

    # inheriting the tk and creating tk
    def __int__(self):
        super.__init__()
