"""
    Module View
    This Is A Frontend Which User Sees And Input Data
"""

# importing required modules
import re
from tkinter import *
from Model.LoginModel import LoginModel
from tkinter.messagebox import showinfo, showerror


# creating login page class
class LoginPage:

    # creating frames and placing in the tk
    def __init__(self, window, controller):

        self.__id = None
        self.__mod = LoginModel()
        self.__window = window
        self.__controller = controller
        self.__window.title("Login Page")
        self.__window.geometry('450x285+450+200')
        self.__emregex = ('^[a-z0-9]+[\._]?[a-z0-9]+[@]\w+[.]\w{2,3}$')  # regex for email only
        self.__passregex = ("^.*(?=.{8,})(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).*$")  # regex for password only

        mainf = Frame(self.__window, bg="Light Grey")
        mainf.pack(fill="both", expand=True)

        title = Frame(mainf, bg="Light Grey")
        title.pack(expand=True)

        titlelb = Label(title, text="Welcome To S&S Taxi Service", font=("", 30, "bold"), bg="Light Grey", fg="Black")
        titlelb.pack(pady=20)

        lbtxt = Frame(mainf, bg="Light Grey")
        lbtxt.pack(expand=True, anchor="center")

        empw = Frame(lbtxt, bg="Light Grey")
        empw.pack(padx=20, side="left")

        em = Label(empw, text="Email : ", font=("", 20, "bold"), bg="Light Grey", fg="Black")
        em.pack()
        Label(empw, bg="light Grey").pack()
        pw = Label(empw, text="Password : ", font=("", 20, "bold"), bg="Light Grey", fg="Black")
        pw.pack()
        Label(empw, bg="light Grey").pack()

        txtfield = Frame(lbtxt, bg="Light Grey")
        txtfield.pack(padx=20, side="right")

        self.emtext = Entry(txtfield, bg="White", fg="Black", font=("", 20))
        self.emtext.insert(0, "Enter your email")
        self.emtext.pack()
        self.emtext.bind('<FocusIn>', self.clear_text)

        self.emt = Label(txtfield, font=("", 10), bg="Light Grey", fg="Black")
        self.emt.pack()

        self.__pwtext = Entry(txtfield, bg="White", fg="Black", font=("", 20))
        self.__pwtext.insert(0, "Enter your password")
        self.__pwtext.pack()
        self.__pwtext.bind('<FocusIn>', self.clear_text1)

        self.emt1 = Label(txtfield, font=("", 10), bg="Light Grey", fg="Black")
        self.emt1.pack()

        log = Frame(mainf, bg="Light Grey")
        log.pack(expand=True)

        self.checkvar = IntVar()
        checkbox = Checkbutton(log, text="Show Password", variable=self.checkvar, onvalue=1, offvalue=0,
                               bg="Light Grey", fg="Black")
        checkbox.pack(pady=10)
        checkbox.bind('<Button-1>', self.showpass)

        btn = Frame(log, bg="Light Grey")
        btn.pack()

        admin = Button(btn, text="Login as Admin", bg="Light Grey", command=self.__controller.admin, bd=0)
        admin.pack(padx=30, side="left")

        signup = Button(btn, text="Register Now", bg="Light Grey", command=controller.reg, bd=0)
        signup.pack(padx=10, side="right")

        nry = Label(btn, text="Not Registered Yet", bg="Light Grey", fg="Black")
        nry.pack(side="right")

        ad = Frame(mainf, bg="Light Grey")
        ad.pack(expand=True)

        logb = Button(ad, text='Login', bg="Light Grey", command=self.verify, bd=0)
        logb.pack()

        self.__window.bind('<Return>', self.callverify)

    # calling verify
    def callverify(self, _):
        self.verify()

    # verifying the data entered
    def verify(self):
        a = self.em()
        b = self.pas()
        if a and b:
            custid = self.__mod.cust()
            did = self.__mod.driver()
            if custid:
                for data in custid:
                    self.__id = data[0]
                    fname = data[1]
                    lname = data[2]
                    message = "Welcome " + lname + " " + fname
                    showinfo("Message", message)
                self.__controller.custlog(self.__id)
            elif did:
                for data in did:
                    self.__id = data[0]
                    fname = data[1]
                    lname = data[2]
                    message = "Welcome " + lname + " " + fname
                    showinfo("Message", message)
                self.__controller.driverdash(self.__id)
            else:
                showerror('Invalid', "Invalid Email or Password")

    # verifying the email
    def em(self):
        email = self.emtext.get().lower()
        if not self.emtext.get() or self.emtext.get() == "Enter your email":
            self.emt.config(text="Email Can't Be Empty", font=("", 10), fg="Red")
            return False
        elif not re.match(self.__emregex, email):
            self.emt.config(text="Invalid Email", font=("", 10), fg="Red")
            return False
        else:
            self.emt.config(text="")
            self.__mod.setem(email)
            return True

    # verifying the password
    def pas(self):
        if not self.__pwtext.get() or self.__pwtext.get() == "Enter your password":
            self.emt1.config(text="Password Can't Be Empty", font=("", 10), fg="Red")
            return False
        elif not re.match(self.__passregex, self.__pwtext.get()):
            self.emt1.config(text="Invalid Password", font=("", 10), fg="Red")
            return False
        else:
            self.emt1.config(text="")
            self.__mod.setpas(self.__pwtext.get())
            return True

    # clearing email textfield
    def clear_text(self, event):
        if self.emtext.get() == "Enter your email":
            self.emtext.delete(0, END)
        if not self.__pwtext.get():
            self.__pwtext.insert(0, "Enter your password")
            self.__pwtext.config(show="")

    # clearing password textfield
    def clear_text1(self, event):
        if self.__pwtext.get() == "Enter your password":
            self.__pwtext.delete(0, END)
            if not self.checkvar.get():
                self.__pwtext.config(show="*")
        if not self.emtext.get():
            self.emtext.insert(0, "Enter your email")

    # showing and hiding password
    def showpass(self, event):
        if self.__pwtext.get() != "Enter your password":
            if self.checkvar.get():
                self.__pwtext.config(show="*")
            else:
                self.__pwtext.config(show="")
        else:
            showinfo("Message", "Password not entered")
            if self.checkvar.get():
                self.checkvar.set(1)
            else:
                self.checkvar.set(0)
