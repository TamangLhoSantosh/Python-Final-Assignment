"""
    Module View
    This Is A Frontend Which User Sees And Input Data
"""

# importing required modules
import re
from tkinter import *
from tkinter import ttk
from tkinter.ttk import Combobox
from geopy.distance import geodesic
from datetime import date, timedelta
from Model.TripModel import TripModel
from tkcalendar.dateentry import Calendar
from Model.CustomerModel import CustomerModel
from tkinter.messagebox import askyesno, showinfo, showerror
from tkintermapview import TkinterMapView, convert_coordinates_to_address, convert_address_to_coordinates


# creating custdashboard
class CustDashboard(ttk.Frame):

    def __init__(self, window, controller, custid):

        self.__tripmod = TripModel()
        self.__custmod = CustomerModel()
        self.__custid = custid
        self.__window = window
        self.__window.deiconify()
        self.__controller = controller
        super().__init__(self.__window)
        self.__window.geometry('1920x1080')
        self.__window.title("Home")
        self.triptable = None
        self.__nmregex = ("[A-Z][a-z]{2,15}")  # firstname, lastname regex
        self.__conregx = ("[9]{1}[\d]{9}")  # contact regex

        mainf = Frame(self.__window, bg="Light Grey")
        mainf.pack(fill="both", expand=True)

        top = Frame(mainf, bg="Light Grey")
        top.pack(fill="x", pady=5)

        title = Frame(mainf, bg="Light Grey")
        title.pack(side="top", pady=5)

        titlelb = Label(title, text="Welcome to S&S Taxi Service", bg="Light Grey", fg="Black", font=("", 30, "bold"))
        titlelb.pack(anchor="center")

        self.logo = PhotoImage(file='Resource/logo.png')
        self.show = Button(top, image=self.logo, bd=0, command=self.call)
        self.show.pack(side='left', padx=10)

        logout = Button(top, text="Logout", bg="light Grey", fg="Black", bd=0, command=self.confirm)
        logout.pack(side="right", padx=2)

        profile = Button(top, text="Profile", bg="light Grey", fg="Black", bd=0, command=self.callprofile)
        profile.pack(side="right", padx=2)

        self.table = Frame(mainf, bg='Light Grey')
        self.table.pack(expand=True, pady=40)

        style = ttk.Style(self.table)
        # set ttk theme to "clam" which support the field background option
        style.theme_use("clam")
        style.configure("Treeview", background="White", foreground="Black")

        self.scrollbar = Scrollbar(self.table)
        self.scrollbar.pack(side='right', fill='y')

        self.owntriptable()

        main = Frame(mainf, bg="Light Grey")
        main.pack(pady=50)

        makeb = Frame(main, bg="Light Grey")
        makeb.pack(anchor='center')

        make = Button(makeb, text="Book A Trip Now", bg="light Grey", fg="Black", bd=0, font=("", 20, "bold"),
                      command=self.call)
        make.pack()

        bottomf = Frame(mainf, bg='Light Grey')
        bottomf.pack(side='bottom', pady=20)

        aboutus = Frame(bottomf, bg='Light Grey')
        aboutus.pack(side='left', padx=20)

        aboutlb = Label(aboutus, text='About Us', bg='Light Grey', fg='Black', font=('', 18))
        aboutlb.pack(anchor='center', pady=10)

        aboucon = Text(aboutus, width=50, height=6, bg='White', fg='Black', bd=0)
        aboucon.pack(anchor='center')
        aboucon.insert(1.0, "S&S Taxi Service is registered under the Office of Company Register Kathmandu. The "
                            "business will be operated as Private Limited Company with one shareholder with the "
                            "objectives of providing Customer Satisfaction & Social Corporate Responsibility "
                            "within Nepal.")
        aboucon.config(state='disabled')

        contactus = Frame(bottomf, bg='Light Grey')
        contactus.pack(side='right', padx=20)

        contactlb = Label(contactus, text='Contact Us', bg='Light Grey', fg='Black', font=('', 18))
        contactlb.pack(anchor='center', pady=10)

        concon = Text(contactus, width=50, height=6, bg='White', fg='Black', bd=1)
        concon.pack(anchor='center')
        concon.insert(1.0, "email        : sands@gmail.com                    "
                           "facebook id  : S&S Taxi Service                   "
                           "instagram id : S&S_Taxi_Service                   "
                           "contact      : +977 9856374856                    "
                           "telephone    : +977 01-018204")
        concon.config(state='disabled')

    # calling profile top level
    def callprofile(self):
        top = Toplevel()
        top.geometry('550x500+450+250')
        top.title("Profile")

        # always top
        top.transient(self.__window)
        top.grab_set()
        self.profile(top)

    # calling booking page
    def call(self):
        self.__controller.book(self.__custid)

    # creating table and adding
    def owntriptable(self):

        self.triptable = ttk.Treeview(self.table, yscrollcommand=self.scrollbar.set, selectmode="extended")
        self.triptable.pack()

        self.scrollbar.config(command=self.triptable.yview)

        # defining columns
        self.triptable["columns"] = ("Trip ID", "Pick Up Location", "Destination", "No Of Passenger", "Departure Date",
                                     "Departure Time", "Distance", "Cost", "Status")

        # formatting columns
        self.triptable.column("#0", width=0, stretch=NO)
        self.triptable.column("Trip ID", width=80, minwidth=90, anchor=W)
        self.triptable.column("Pick Up Location", width=180, minwidth=90, anchor=W)
        self.triptable.column("Destination", width=180, minwidth=90, anchor=W)
        self.triptable.column("No Of Passenger", width=100, minwidth=90, anchor=W)
        self.triptable.column("Departure Date", width=180, minwidth=90, anchor=W)
        self.triptable.column("Departure Time", width=180, minwidth=90, anchor=W)
        self.triptable.column("Distance", width=180, minwidth=90, anchor=W)
        self.triptable.column("Cost", width=180, minwidth=90, anchor=W)
        self.triptable.column("Status", width=180, minwidth=90, anchor=W)

        # creating heading
        self.triptable.heading("#0", text='Label')
        self.triptable.heading("Trip ID", text="Trip Id")
        self.triptable.heading("Pick Up Location", text="Pick Up Location")
        self.triptable.heading("Destination", text="Destination")
        self.triptable.heading("No Of Passenger", text="No Of Passenger")
        self.triptable.heading("Departure Date", text="Departure Date")
        self.triptable.heading("Departure Time", text="Departure Time")
        self.triptable.heading("Distance", text="Distance")
        self.triptable.heading("Cost", text="Cost")
        self.triptable.heading("Status", text="Status")

        # reading data from table
        record = self.__tripmod.custrip(self.__custid)

        if record:

            # inserting data into table
            for data in record:
                self.triptable.insert("", index="end",
                                      values=(data[0], data[2], data[3], data[6], data[4], data[5], data[7], data[8]
                                              , data[9]))

            self.triptable.bind('<Double-1>', self.data)

    # confirm logging out
    def confirm(self):
        ans = askyesno("Conformation", "Are You Sure You Want To Log Out?")
        if ans:
            self.__controller.log()

    # creating top level for specific trip
    def data(self, event):
        tripd = None
        try:
            record = None
            if self.triptable.selection()[0]:
                for data in self.triptable.selection():
                    value = self.triptable.item(data)
                    tripd = value['values']
                tp = Toplevel()

                # always top
                tp.transient(self.__window)
                tp.grab_set()
                if tripd[8] == 'Pending' or tripd[8] == 'Cancelled':
                    record = self.__tripmod.tripdetail(tripd[0])
                else:
                    record = self.__tripmod.tripdetails(tripd[0])
                self.details(tp, record)
        except Exception as e:
            showinfo("Message", "Select A Data")
            print(e)

    def details(self, top, record):
        for data in record:

            top = top
            top.geometry('500x380+450+235')
            top.title('Trip Details')

            mainf = Frame(top, bg='White')
            mainf.pack(fill='both', expand=True)

            titlef = Frame(mainf, bg='White')
            titlef.pack(pady=10)

            title = Label(titlef, text='Trip Detail', bg='White', fg='Black', font=('EB Garamond', 25, 'bold'))
            title.pack(anchor='center')

            locationf = Frame(mainf, bg='White')
            locationf.pack(pady=10)

            picklocation = Frame(locationf, bg='White')
            picklocation.pack(side='left', padx=10)

            pickloc = Label(picklocation, text='Pickup : ', bg='White', fg='Black', font=('Crimson Text', 18))
            pickloc.pack(side='left', padx=10)

            picklocdata = Label(picklocation, text=data[2], bg='White', fg='Black', font=('Crimson Text', 16))
            picklocdata.pack(side='left')

            droplocation = Frame(locationf, bg='White')
            droplocation.pack(side='right', padx=10)

            droploc = Label(droplocation, text='Destination : ', bg='White', fg='Black', font=('Crimson Text', 18))
            droploc.pack(side='left')

            droplocdata = Label(droplocation, text=data[3], bg='White', fg='Black', font=('Crimson Text', 16))
            droplocdata.pack(side='left', padx=10)

            datime = Frame(mainf, bg='White')
            datime.pack(pady=10)

            datef = Frame(datime, bg='White')
            datef.pack(side='left', padx=10)

            datelb = Label(datef, text='Date : ', bg='White', fg='Black', font=('Crimson Text', 18))
            datelb.pack(side='left', padx=10)

            datedata = Label(datef, text=data[4], bg='White', fg='Black', font=('Crimson Text', 16))
            datedata.pack(side='left')

            timef = Frame(datime, bg='White', padx=10)
            timef.pack(side='right')

            timelb = Label(timef, text='Time : ', bg='White', fg='Black', font=('Crimson Text', 18))
            timelb.pack(side='left')

            timedata = Label(timef, text=data[5], bg='White', fg='Black', font=('Crimson Text', 16))
            timedata.pack(side='left', padx=10)

            statupass = Frame(mainf, bg='White')
            statupass.pack(pady=10)

            passengerf = Frame(statupass, bg='White')
            passengerf.pack(side='left', padx=10)

            passengerlb = Label(passengerf, text='Passenger : ', bg='White', fg='Black', font=('Crimson Text', 18))
            passengerlb.pack(side='left', padx=10)

            passegerdata = Label(passengerf, text=data[6], bg='White', fg='Black', font=('Crimson Text', 16))
            passegerdata.pack(side='left')

            statusf = Frame(statupass, bg='White')
            statusf.pack(side='right', padx=10)

            statuslb = Label(statusf, text='Status : ', bg='White', fg='Black', font=('Crimson Text', 18))
            statuslb.pack(side='left')

            statusdata = Label(statusf, text=data[9], bg='White', fg='Black', font=('Crimson Text', 16))
            statusdata.pack(side='left', padx=10)

            distcost = Frame(mainf, bg='White')
            distcost.pack(pady=10)

            distf = Frame(distcost, bg='White')
            distf.pack(side='left', padx=10)

            distlb = Label(distf, text="Distance : ", bg='White', fg='Black', font=('Crimson Text', 18))
            distlb.pack(side='left', padx=10)

            distdata = Label(distf, text=data[7], bg='White', fg='Black', font=('Crimson Text', 16))
            distdata.pack(side='left')

            costf = Frame(distcost, bg='White')
            costf.pack(side='right', padx=10)

            costlb = Label(costf, text="Cost : ", bg='White', fg='Black', font=('Crimson Text', 18))
            costlb.pack(side='left')

            costdata = Label(costf, text=data[8], bg='White', fg='Black', font=('Crimson Text', 16))
            costdata.pack(side='left', padx=10)

            driverf = Frame(mainf, bg='White')
            driverf.pack(pady=10)

            drivernamef = Frame(driverf, bg='White')
            drivernamef.pack(side='left', padx=10)

            drivernamelb = Label(drivernamef, text='Driver Name : ', bg='White', fg='Black', font=('Crimson Text', 18))
            drivernamelb.pack(side='left', padx=10)

            drivernamedata = Label(drivernamef, text='Pending', bg='White', fg='Black', font=('Crimson Text', 16))
            drivernamedata.pack(side='left')

            driverconf = Frame(driverf, bg='White')
            driverconf.pack(side='right', padx=10)

            driverconlb = Label(driverconf, text="Driver Contact : ", bg='White', fg='Black', font=('Crimson Text', 18))
            driverconlb.pack(side='left')

            drivercondata = Label(driverconf, text='Pending', bg='White', fg='Black', font=('Crimson Text', 16))
            drivercondata.pack(side='left', padx=10)

            vehiclef = Frame(mainf, bg='White')
            vehiclef.pack(pady=10)

            vehiclenamef = Frame(vehiclef, bg='White')
            vehiclenamef.pack(side='left', padx=10)

            vehiclenamelb = Label(vehiclenamef, text='Vehicle Type : ', bg='White', fg='Black', font=('Crimson Text', 18))
            vehiclenamelb.pack(side='left', padx=20)

            vehiclenamedata = Label(vehiclenamef, text='Pending', bg='White', fg='Black', font=('Crimson Text', 16))
            vehiclenamedata.pack(side='left')

            vehiclenof = Frame(vehiclef, bg='White')
            vehiclenof.pack(side='right')

            vehiclenolb = Label(vehiclenof, text='Vehicle No : ', bg='White', fg='Black', font=('Crimson Text', 18))
            vehiclenolb.pack(side='left')

            vehiclenodata = Label(vehiclenof, text='Pending', bg='White', fg='Black', font=('Crimson Text', 16))
            vehiclenodata.pack(side='left', padx=10)

            if not data[9] == 'Pending' and not data[9] == 'Cancelled':
                dname = data[17] + " " + data[16]
                vname = data[28] + " " + data[29]
                drivernamedata.config(text=dname)
                drivercondata.config(text=data[21])
                vehiclenamedata.config(text=vname)
                vehiclenodata.config(text=data[27])
            else:
                drivernamedata.config(text='Pending')
                drivercondata.config(text='Pending')
                vehiclenamedata.config(text='Pending')
                vehiclenodata.config(text='Pending')

            btn = Frame(mainf, bg='White')
            btn.pack(expand=True, pady=10)

            cancelf = Frame(btn, bg='White')
            cancelf.pack(side='left', padx=10)

            cancel = Button(cancelf, text='Cancel Trip', bg='Light Grey', fg='Black', bd=0
                            , command=lambda: canceltrip(top))
            cancel.pack(anchor='center')

            deletef = Frame(btn, bg='White')
            deletef.pack(side='right', padx=10)

            delete = Button(deletef, text='Delete Trip', bg='Light Grey', fg='Black', bd=0
                            , command=lambda: deletetrip(top))
            delete.pack(anchor='center')

        # cancelling trip
        def canceltrip(top):
            if data[9] == "Cancelled":
                showinfo("Message", 'Trip Already Cancelled')
            elif data[9] == "Pending":
                if self.__tripmod.canceltrip(data[0]):
                    ans = askyesno("Conformation", "Are You Sure You Want To Cancel The Trip?")
                    if ans:
                        showinfo("Messsage", "Trip Cancelled Succefully")
                        top.destroy()
                        self.triptable.destroy()
                        self.owntriptable()
            else:
                showinfo("Message", "Trip Can Not Be Cancelled Now")
                top.destroy()

        def deletetrip(top):
            if data[9] == "Cancelled" or data[9] == "Pending":
                if self.__tripmod.deletetrip(data[0]):
                    ans = askyesno("Conformation", "Are You Sure You Want To Delete The Trip?")
                    if ans:
                        showinfo("Message", "Trip Deleted Successfully")
                        top.destroy()
                        self.triptable.destroy()
                        self.owntriptable()
            else:
                showinfo("Message", "Trip Can Not Be Deleted Now")
                top.destroy()

    # creating profile top level
    def profile(self, topf):

        top = topf
        mainf = Frame(top, bg="Light Grey")
        mainf.pack(fill="both", expand=True)

        title = Frame(mainf, bg="Light Grey")
        title.pack(side="top", pady=5)

        titlelb = Label(title, text="Profile", bg="Light Grey", fg="Black", font=("", 30, "bold"))
        titlelb.pack(anchor="center")

        lbdata = Frame(mainf, bg='Light Grey')
        lbdata.pack(pady=10)

        lb = Frame(lbdata, bg='Light Grey')
        lb.pack(side='left', padx=20, pady=10)

        fnamelb = Label(lb, text='First Name : ', bg='Light Grey', fg='Black', font=('', 18))
        fnamelb.pack(anchor='center')

        Label(lb, bg='Light Grey').pack()

        lnamelb = Label(lb, text='Last Name : ', bg='Light Grey', fg='Black', font=('', 18))
        lnamelb.pack(anchor='center')

        Label(lb, bg='Light Grey').pack()

        doblb = Label(lb, text='Date Of Birth : ', bg='Light Grey', fg='Black', font=('', 18))
        doblb.pack(anchor='center')

        Label(lb, bg='Light Grey').pack()

        genderlb = Label(lb, text='Gender : ', bg='Light Grey', fg='Black', font=('', 18))
        genderlb.pack(anchor='center')

        Label(lb, bg='Light Grey').pack()

        addresslb = Label(lb, text='Address : ', bg='Light Grey', fg='Black', font=('', 18))
        addresslb.pack(anchor='center')

        Label(lb, bg='Light Grey').pack()

        contactlb = Label(lb, text='Contact : ', bg='Light Grey', fg='Black', font=('', 18))
        contactlb.pack(anchor='center')

        Label(lb, bg='Light Grey').pack()

        emailb = Label(lb, text='Email : ', bg='Light Grey', fg='Black', font=('', 18))
        emailb.pack(anchor='center')

        data = Frame(lbdata, bg='Light Grey')
        data.pack(side='right', padx=20, pady=10)

        fn = StringVar()
        fname = Entry(data, state='readonly', fg='Light Grey', readonlybackground='Black', textvariable=fn)
        fname.pack(anchor='center')

        Label(data, bg='Light Grey').pack()

        ln = StringVar()
        lname = Entry(data, state='readonly', fg='Light Grey', readonlybackground='Black', textvariable=ln)
        lname.pack(anchor='center')

        Label(data, bg='Light Grey').pack()

        db = StringVar()
        dob = Entry(data, state='readonly', fg='White', readonlybackground='Black', textvariable=db)
        dob.pack(anchor='center')

        Label(data, bg='Light Grey').pack()

        gen = StringVar()
        gender = Entry(data, state='readonly', fg='Light Grey', readonlybackground='Black', textvariable=gen)
        gender.pack(anchor='center')

        Label(data, bg='Light Grey').pack()

        add = StringVar()
        address = Entry(data, state='readonly', fg='Light Grey', readonlybackground='Black', textvariable=add)
        address.pack(anchor='center')

        Label(data, bg='Light Grey').pack()

        con = StringVar()
        contact = Entry(data, state='readonly', fg='Light Grey', readonlybackground='Black', textvariable=con)
        contact.pack(anchor='center')

        Label(data, bg='Light Grey').pack()

        em = StringVar()
        email = Entry(data, state='readonly', fg='White', readonlybackground='Black', textvariable=em)
        email.pack(anchor='center')

        record = self.__custmod.details(self.__custid)
        for data in record:
            fn.set(data[1])
            ln.set(data[2])
            db.set(data[3])
            gen.set(data[4])
            add.set(data[5])
            con.set(data[6])
            em.set(data[7])

        btn = Frame(mainf, bg='Light Grey')
        btn.pack(pady=10)

        editbtn = Frame(btn, bg='Light Grey')
        editbtn.pack(side='left', padx=10, fill='both')

        edit = Button(editbtn, text='Edit', bd=0, bg='#F2F3F5', fg='Black', command=lambda: editdetail(top))
        edit.pack(anchor='center')

        deletebtn = Frame(btn, bg='Light Grey')
        deletebtn.pack(side='right', padx=10, fill='both')

        delete = Button(deletebtn, text='Delete', bd=0, bg='#F2F3F5', fg='Black', command=lambda: deleteacc())
        delete.pack(anchor='center')

        def editdetail(top):
            edit.destroy()
            delete.destroy()
            fname.config(state='normal')
            fname.config(bg='White', fg='Black')
            lname.config(state='normal')
            lname.config(bg='White', fg='Black')
            address.config(state='normal')
            address.config(bg='White', fg='Black')
            contact.config(state='normal')
            contact.config(bg='White', fg='Black')
            confirmedit = Button(editbtn, text='Confirm Edit', bd=0, bg='#F2F3F5', fg='Black',
                                 command=lambda: insertdetail(top))
            confirmedit.pack(anchor='center')
            canceledit = Button(deletebtn, text='Cancel Edit', bd=0, bg='#F2F3F5', fg='Black',
                                command=lambda: cancel(top))
            canceledit.pack(anchor='center')

        def insertdetail(top):
            a = fnval()
            b = lnval()
            c = addval()
            d = conval()
            if a and b and c and d:
                if self.__custmod.updatedetatil(self.__custid):
                    ans = askyesno("Conformation", "Are You Sure You Want To Change Te Detail?")
                    if ans:
                        showinfo("Messasge", "Profile Succefully Updated")
                        top.destroy()

        def fnval():
            if not fn.get():
                showinfo("Message", "First Name Can Not Be Empty.")
                return False
            elif not re.match(self.__nmregex, fn.get()):
                showinfo("Message", 'Invalid First Name')
                return False
            else:
                self.__custmod.setfn(fn.get())
                return True

        def lnval():
            if not ln.get():
                showinfo("Message", "Last Name Can Not Be Empty.")
                return False
            elif not re.match(self.__nmregex, ln.get()):
                showinfo("Message", 'Invalid Last Name')
                return False
            else:
                self.__custmod.setln(ln.get())
                return True

        def addval():
            if not add.get():
                showinfo("Message", 'Address Can Not Be Empty.')
                return False
            else:
                self.__custmod.setadd(add.get())
                return True

        def conval():
            if not con.get():
                showinfo("Message", 'Contact Can Not Be Empty.')
                return False
            elif not re.match(self.__conregx, con.get()):
                showinfo("Message", 'Invalid Contact')
                return False
            else:
                self.__custmod.setcon(con.get())
                return True

        def cancel(top):
            top.destroy()

        def deleteacc():
            if self.__custmod.delete(self.__custid):
                ans = askyesno("Conformation", "Are You Sure You Want To Delete The Account?")
                if ans:
                    showinfo("Message", 'Account Deleted Successfully')
                    self.__controller.log()


# creating page with map
# creating booking page class
class BookingPage(ttk.Frame):

    # managing the top level
    def __init__(self, window, controller, custid):

        self.__custid = custid
        self.cord1 = None
        self.cord2 = None
        self.mark1 = None
        self.mark2 = None
        self.path1 = None
        self.distance = None
        self.cal = None
        self.top = None
        self.__ndate = None
        self.__mod = TripModel()
        self.__window = window
        self.__controller = controller
        super().__init__(self.__window)
        self.__window.geometry('1920x1080')
        self.__window.title("Map")
        self.__numregex = "[0-9]"  # checking for number only

        mainf = Frame(window, bg='Light Grey')
        mainf.pack(expand=True, fill='both')

        lbentry = Frame(mainf, bg='Light Grey')
        lbentry.pack(pady=10)

        lb = Frame(lbentry, bg="Light Grey")
        lb.pack(side='left', pady=10, padx=10)

        pickuplb = Label(lb, text='Pickup', bg='Light Grey', fg='Black', font=("", 18))
        pickuplb.pack()

        Label(lb, bg='Light Grey').pack()

        droplb = Label(lb, text='Destination', bg='Light Grey', fg='Black', font=("", 18))
        droplb.pack()

        Label(lb, bg='Light Grey').pack()

        btn = Frame(lbentry, bg='Light Grey')
        btn.pack(side='right', padx=10)

        pickbtn = Button(btn, text='Search', bd=0, command=self.pick_up)
        pickbtn.pack()

        Label(btn, bg='Light Grey').pack()

        dropbtn = Button(btn, text='Search', bd=0, command=self.drop_loc)
        dropbtn.pack()

        Label(btn, bg='Light Grey').pack()

        entry = Frame(lbentry, bg='Light Grey')
        entry.pack(side='right', pady=10)

        self.pickup = Entry(entry, bg='White', fg='Black', font=("", 18))
        self.pickup.pack()

        self.pickupemt = Label(entry, bg='Light Grey')
        self.pickupemt.pack()

        self.drop = Entry(entry, bg='White', fg='Black', font=("", 18))
        self.drop.pack()

        self.dropemt = Label(entry, bg='Light Grey')
        self.dropemt.pack()

        details = Frame(mainf, bg='Light Grey')
        details.pack(side='right', padx=20, pady=20)

        label_frame = Frame(details, bg='Light Grey')
        label_frame.pack(side='left', padx=10)

        tile = Label(label_frame, text='Change Map', bg='Light Grey', fg='Black', font=("", 18))
        tile.pack()

        Label(label_frame, bg='Light Grey').pack()

        passlb = Label(label_frame, text='No Of Passengers', bg='Light Grey', fg='Black', font=("", 18))
        passlb.pack()

        Label(label_frame, bg='Light Grey').pack()

        pickdate = Label(label_frame, text='Pickup Date', bg='Light Grey', fg='Black', font=("", 18))
        pickdate.pack()

        Label(label_frame, bg='Light Grey').pack()

        picktime = Label(label_frame, text='Pickup Time', bg='Light Grey', fg='Black', font=("", 18))
        picktime.pack()

        Label(label_frame, bg='Light Grey').pack()

        total_cost = Label(label_frame, text='Total Cost', bg='Light Grey', fg='Black', font=("", 18))
        total_cost.pack()

        Label(label_frame, bg='Light Grey').pack()

        entry_frame = Frame(details, bg='Light Grey')
        entry_frame.pack(side='right', padx=10)

        self.map_type = StringVar()
        map_types = ['Google Map', 'Google satellite', 'Open Street Map']
        self.__choice = Combobox(entry_frame, textvariable=self.map_type, values=map_types, state='readonly',
                                 justify='center')
        self.__choice.set('Google Map')
        self.__choice.pack()
        self.__choice.bind("<<ComboboxSelected>>", self.map_change)

        Label(entry_frame, bg='Light Grey').pack()

        self.__no = list((range(1, 5)))
        self.__noofpass = IntVar()
        self.__passanger = Spinbox(entry_frame, values=self.__no, state='readonly', justify='center', wrap=True,
                                   textvariable=self.__noofpass)
        self.__passanger.pack()

        Label(entry_frame, bg='Light Grey').pack()

        datef = Frame(entry_frame, bg='Light Grey')
        datef.pack()

        now = date.today() + timedelta(days=1)
        self.pd = StringVar()
        self.pickdate = Entry(datef, state='readonly', readonlybackground='White', fg='Black', textvariable=self.pd)
        self.pd.set(str(now))
        self.pickdate.pack(side='left')

        self.showcale = PhotoImage(file='Resource/calendar.png')
        self.__calendar = Button(datef, image=self.showcale, command=self.showcalendar, bd=0)
        self.__calendar.pack()

        self.datemt = Label(entry_frame, bg='Light Grey')
        self.datemt.pack()

        timef = Frame(entry_frame, bg='Light Grey')
        timef.pack()

        hrs = list(range(1, 13))
        self.__hour = StringVar()
        self.hour = Spinbox(timef, values=hrs, textvariable=self.__hour, justify='center', width=5, wrap=True,
                            bg='Light Grey', fg='Black')
        self.__hour.set("6")
        self.hour.pack(side='left')

        Label(timef, text=':', bg='Light Grey', fg='Black', font=('', 18)).pack(side='left', padx=2)

        mins = list(range(1, 60))
        mins.insert(0, '00')
        self.__minute = StringVar()
        self.minute = Spinbox(timef, values=mins, textvariable=self.__minute, justify='center', width=5, wrap=True,
                              bg='Light Grey', fg='Black')
        self.minute.pack(side='left')

        apm = list(("AM", "PM"))
        self.__apm = StringVar()
        self.apm = Spinbox(timef, values=apm, textvariable=self.__apm, state='readonly', justify='center', width=3,
                           wrap=True, bg='Black', fg='Light Grey')
        self.apm.pack(side='left', padx=2)

        self.timemt = Label(entry_frame, bg='Light Grey')
        self.timemt.pack()

        costf = Frame(entry_frame, bg="Light Grey")
        costf.pack()

        Label(costf, text="Rs.", bg='Light Grey', fg='Black').pack(side='left')

        Label(costf, text=":", bg='Light Grey', fg='Black').pack(side='left', padx=2)

        self.__cost = Label(costf, text='*****', bg='Light Grey', fg='Black')
        self.__cost.pack(side='left')

        Label(entry_frame, bg='Light Grey').pack()

        back = Button(label_frame, text='Back', command=self.call, bg='Light Grey',
                      fg='Black', bd=0)
        back.pack()

        bookbtn = Button(entry_frame, text='Book', bg="Light Grey", fg="BLack", bd=0, command=self.book)
        bookbtn.pack()

        frame = Frame(mainf, bg="Light Grey", highlightbackground="BLack", highlightthickness=2)
        frame.pack(padx=15)

        mapf = Frame(frame, bg='Light Grey')
        mapf.pack(fill='both', anchor='center')

        # adding map
        self.map = TkinterMapView(mapf, width=1000, height=700, corner_radius=0)

        # setting tile to google map
        self.map.set_tile_server("https://mt0.google.com/vt/lyrs=m&hl=en&x={x}&y={y}&z={z}&s=Ga",
                                 max_zoom=22)  # Google Normal Map

        # setting opening address
        self.map.set_position(27.6845, 85.3170)  # PCPS, Kupandole
        self.map.set_zoom(18)  # setting zoom level to 18
        self.map.pack()
        self.map.add_left_click_map_command(self.address)  # binding event

    # changing map tile
    def map_change(self, _):
        if self.map_type.get() == 'Open Street Map':
            self.map.set_tile_server("https://a.tile.openstreetmap.org/{z}/{x}/{y}.png")  # OpenStreetMap (default)
        elif self.map_type.get() == 'Google Map':
            self.map.set_tile_server("https://mt0.google.com/vt/lyrs=m&hl=en&x={x}&y={y}&z={z}&s=Ga",
                                     max_zoom=22)  # Google Normal Map
        else:
            self.map.set_tile_server("https://mt0.google.com/vt/lyrs=s&hl=en&x={x}&y={y}&z={z}&s=Ga",
                                     max_zoom=22)  # google satellite

    # converting coordinates to address
    def address(self, cords):
        adr = convert_coordinates_to_address(cords[0], cords[1])
        if not self.pickup.get():
            self.cord1 = cords
            if self.mark1:
                self.mark1.delete()
                self.path1.delete()
            if adr.street:
                ls = adr.street + ',' + adr.city
                self.pickup.insert(0, ls)
            else:
                ls = adr.latlng
                self.pickup.insert(0, ls)
            self.marker()
        elif not self.drop.get():
            self.cord2 = cords
            if self.mark2:
                self.mark2.delete()
                self.path1.delete()
            if adr.street:
                ls = adr.street + ',' + adr.city
                self.drop.insert(0, ls)
            else:
                ls = adr.latlng
                self.drop.insert(0, ls)
            self.marker()

    # marking the location entered
    def pick_up(self):
        if not self.pickup.get():
            self.pickupemt.config(text='Enter A Location', font=('', 10), fg='Red')
        else:
            self.pickupemt.config(text='')
            self.cord1 = convert_address_to_coordinates(self.pickup.get())
            if self.cord1:
                cords = self.cord1
                self.map.set_position(cords[0], cords[1])
                self.map.set_zoom(18)
                if self.mark1:
                    self.mark1.delete()
                    if self.path1:
                        self.path1.delete()
                self.marker()
            else:
                self.pickupemt.config(text='Location Can Not Be Found.', font=('', 10), fg='Red')

    # marking the location entered
    def drop_loc(self):
        if not self.drop.get():
            self.dropemt.config(text='Enter A Location', font=('', 10), fg='Red')
        else:
            self.dropemt.config(text='')
            self.cord2 = convert_address_to_coordinates(self.drop.get())
            if self.cord2:
                cords = self.cord2
                self.map.set_position(cords[0], cords[1])
                self.map.set_zoom(18)
                if self.mark2:
                    self.mark2.delete()
                    if self.path1:
                        self.path1.delete()
                self.marker()
            else:
                self.dropemt.config(text='Location Can Not Be Found.', font=('', 10), fg='Red')

    # making marker
    def marker(self):
        if self.pickup.get():
            cords = self.cord1
            self.mark1 = self.map.set_marker(cords[0], cords[1])
        if self.drop.get():
            cords = self.cord2
            self.mark2 = self.map.set_marker(cords[0], cords[1])
        if self.pickup.get() and self.drop.get():
            self.path()

    # creating path when there is two markers
    def path(self):
        if self.cord1 and self.cord2:
            self.path1 = self.map.set_path([self.cord1, self.cord2])
            self.distance = geodesic(self.cord1, self.cord2).km
            self.cost()

    # calculating the total cost
    def cost(self):
        mindistance = 2
        mincost = 150
        price = 0
        if self.distance == mindistance:
            price = mincost
        elif mindistance < self.distance <= 10:
            price = mincost + (self.distance - mindistance) * 30
        elif self.distance <= 20:
            price = mincost + (self.distance - mindistance) * 50
        elif self.distance > 20:
            price = mincost + (self.distance - mindistance) * 70
        format_float = "{:.2f}".format(price)
        self.__cost.config(text=format_float)

    # showing calendar and filling the entry with date
    def showcalendar(self):
        tp = Toplevel()

        # always top
        tp.transient(self.__window)
        tp.grab_set()
        self.create(tp)

    # creating calendar
    def create(self, top):
        self.top = top
        self.top.overrideredirect(1)  # Remove border
        self.top.geometry('210x135+1195+532')

        mainf = Frame(self.top, bg='Light Grey')
        mainf.pack(fill='both', expand=True)

        min = date.today() + timedelta(days=1)
        max = date.today() + timedelta(days=15)
        self.cal = Calendar(mainf, selectmode='day', date_pattern='yyy-mm-dd', mindate=min, maxdate=max,
                            showweeknumbers=False, weekendforeground='Red', normalforeground='Black')
        self.cal.bind('<<CalendarSelected>>', self.asd)
        self.cal.pack(fill='both')

    # selecting day and destroying the toplevel
    def asd(self, event):
        self.__ndate = self.cal.get_date()
        self.pd.set(str(self.__ndate))
        self.top.destroy()

    # calling customer dashboard
    def call(self):
        self.__controller.custlog(self.__custid)

    # validating and booking a trip
    def book(self):
        a = self.pickuplocation()
        b = self.droplocation()
        c = self.picktime()
        d = self.totalcost()
        if a and b and c and d:
            self.__mod.setcustid(self.__custid)
            self.__mod.setpassno(self.__passanger.get())
            self.__mod.settripdate(self.pickdate.get())
            if self.__mod.booktrip():
                showinfo('message', "Trip booked")
                self.call()

    def pickuplocation(self):
        if not self.pickup.get():
            self.pickupemt.config(text='Location Can Not Be Empty.', font=('', 10), fg='Red')
            return False
        else:
            self.pickupemt.config(text='')
            self.__mod.setpickloc(self.pickup.get())
            return True

    def droplocation(self):
        if not self.drop.get():
            self.dropemt.config(text='Location Can Not Be Empty.', font=('', 10), fg='Red')
            return False
        else:
            self.dropemt.config(text='')
            self.__mod.setdroploc(self.drop.get())
            return True

    def picktime(self):
        if not re.match(self.__numregex, self.__hour.get()):
            self.timemt.config(text='Invalid Input', font=('', 10), fg='Red')
            return False
        elif int(self.__hour.get()) > 12 or int(self.__hour.get()) < 1:
            self.timemt.config(text='Invalid Input', font=('', 10), fg='Red')
            return False
        elif not re.match(self.__numregex, self.__minute.get()):
            self.timemt.config(text='Invalid Input', font=('', 10), fg='Red')
            return False
        elif int(self.__minute.get()) >= 60 or int(self.__minute.get()) < 0:
            self.timemt.config(text='Invalid Input', font=('', 10), fg='Red')
            return False
        else:
            self.timemt.config(text='')
            time = self.__hour.get() + " : " + self.__minute.get() + " " + self.__apm.get()
            self.__mod.setpicktime(time)
            return True

    def totalcost(self):
        cost = self.__cost.cget("text")
        if cost == '*****':
            showerror('Invalid', "Path Not Marked")
            return False
        else:
            format_float = "{:.2f}".format(self.distance)
            self.__mod.setdistance(format_float)
            self.__mod.setcost(cost)
            return True
