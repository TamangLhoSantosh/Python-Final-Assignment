"""
    Module View
    This Is A Frontend Which User Sees And Input Data
"""

# importing required modules
import re
from tkinter import *
from datetime import datetime
from tkinter.ttk import Combobox
from tkinter.messagebox import showinfo
from Model.RegistrationModel import RegistrationModel


# creating class Registration page
class RegistrationPage:

    # creating frames and placing in the tk
    def __init__(self, window, controller):

        self.__mod = RegistrationModel()
        self.__window = window
        self.__controller = controller
        self.__window.title("Registration Page")
        self.__window.geometry('450x600+450+200')
        self.__nmregex = ("[A-Z][a-z]{2,10}")  # firstname, lastname regex
        self.__conregx = ("[9]{1}[\d]{9}")  # contact regex
        self.__emregex = ("^[a-z0-9]+[\._]?[a-z0-9]+[@]\w+[.]\w{2,3}$")  # regex for email only
        self.__passregex = ("^.*(?=.{8,})(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).*$")  # regex for password only

        mainf = Frame(self.__window, bg="Light Grey")
        mainf.pack(expand=True, fill="both")

        title = Frame(mainf, bg="Light Grey")
        title.pack(expand=True)

        titleb = Label(title, text="Register now", font=("", 30, "bold"), bg="Light Grey", fg="Black")
        titleb.pack(pady=20)

        lbtxt = Frame(mainf, bg="Light Grey")
        lbtxt.pack(anchor="center", expand=True)

        lb = Frame(lbtxt, bg="Light Grey")
        lb.pack(side="left")

        fnlb = Label(lb, text="First Name : ", font=("", 20, "bold"), bg="Light Grey", fg="Black")
        fnlb.pack()

        Label(lb, bg="Light Grey").pack()

        lnlb = Label(lb, text="Last Name : ", font=("", 20, "bold"), bg="Light Grey", fg="Black")
        lnlb.pack()

        Label(lb, bg="Light Grey").pack()

        doblb = Label(lb, text="Date of Birth : ", font=("", 20, "bold"), bg="Light Grey", fg="Black")
        doblb.pack()

        Label(lb, bg="Light Grey").pack()

        genlb = Label(lb, text="Gender : ", font=("", 20, "bold"), bg="Light Grey", fg="Black")
        genlb.pack()

        Label(lb, bg="Light Grey").pack()

        addlb = Label(lb, text="Address : ", font=("", 20, "bold"), bg="Light Grey", fg="Black")
        addlb.pack()

        Label(lb, bg="Light Grey").pack()

        conlb = Label(lb, text="Contact : ", font=("", 20, "bold"), bg="Light Grey", fg="Black")
        conlb.pack()

        Label(lb, bg="Light Grey").pack()

        emaillb = Label(lb, text="E-mail : ", font=("", 20, "bold"), bg="Light Grey", fg="Black")
        emaillb.pack()

        Label(lb, bg="Light Grey").pack()

        passwlb = Label(lb, text="Password : ", font=("", 20, "bold"), bg="Light Grey", fg="Black")
        passwlb.pack()

        Label(lb, bg="Light Grey").pack()

        conplb = Label(lb, text="Confirm Password : ", font=("", 20, "bold"), bg="Light Grey", fg="Black")
        conplb.pack()

        Label(lb, bg="Light Grey").pack()

        txt = Frame(lbtxt, bg="Light Grey")
        txt.pack(side="right")

        self.__fn = Entry(txt, bg="White", fg="Black", font=("", 15))
        self.__fn.pack()

        self.__fnetm = Label(txt, bg="Light Grey")
        self.__fnetm.pack()

        self.__ln = Entry(txt, bg="White", fg="Black", font=("", 15))
        self.__ln.pack()

        self.__lnemt = Label(txt, bg="Light Grey")
        self.__lnemt.pack()

        date = Frame(txt, bg="Light Grey")
        date.pack()

        # using datetime module to find the current year
        x = datetime.now()
        y = x.year - 18
        z = x.year - 100
        self.yea = list(range(z, y))
        self.__yearvar = StringVar()
        self.year = Combobox(date, values=self.yea, textvariable=self.__yearvar, width=4, justify="center")
        self.year.set("Year")
        self.year.pack(side="left")

        mon = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
               "November", "December"]
        self.__monthvar = StringVar()
        self.month = Combobox(date, values=mon, textvariable=self.__monthvar, width=7, justify="center",
                              state='readonly')
        self.month.set("Month")
        self.month.pack(side="left", padx=2)
        self.month.bind("<<ComboboxSelected>>", self.determine)

        self.__dayvar = StringVar()
        self.day = Combobox(date, values=[], textvariable=self.__dayvar, width=3, justify="center", state='readonly')
        self.day.set("Day")
        self.day.pack(side="left")

        self.__datelb = Label(txt, bg="Light Grey")
        self.__datelb.pack()

        self.emt = Label(txt, font=('', 1), bg='Light Grey')
        self.emt.pack()

        radiio = Frame(txt, bg="Light Grey")
        radiio.pack()

        self.__genval = StringVar()
        self.__genval.set('1')
        self.__male = Radiobutton(radiio, text="Male", variable=self.__genval, value="Male")
        self.__male.pack(side='left')
        self.__female = Radiobutton(radiio, text="Female", variable=self.__genval, value="Female")
        self.__female.pack(side='left', padx=10)
        self.__other = Radiobutton(radiio, text="Other", variable=self.__genval, value="Others")
        self.__other.pack(side='left')

        self.__gen = Label(txt, bg="Light Grey")
        self.__gen.pack()

        self.emt2 = Label(txt, font=('', 1), bg='Light Grey')
        self.emt2.pack()

        self.__add = Entry(txt, bg="White", fg="Black", font=("", 15))
        self.__add.pack()

        self.addlb = Label(txt, bg="Light Grey")
        self.addlb.pack()

        self.__con = Entry(txt, bg="White", fg="Black", font=("", 15))
        self.__con.pack()

        self.__conemt = Label(txt, bg="Light Grey")
        self.__conemt.pack()

        self.__email = Entry(txt, bg="White", fg="Black", font=("", 15))
        self.__email.pack()

        self.__ememt = Label(txt, bg="Light Grey")
        self.__ememt.pack()

        passf = Frame(txt, bg="Light Grey")
        passf.pack()

        self.showpass = PhotoImage(file='Resource/showpass.png')
        self.show = Button(passf, image=self.showpass, bd=1, command=self.showpas)
        self.show.pack(side='right')
        self.__x = True
        self.__pass = Entry(passf, bg="White", fg="Black", font=("", 15), show='*', width=17)
        self.__pass.pack(side='right')

        self.__pasemt = Label(txt, bg="Light Grey")
        self.__pasemt.pack()

        conpassf = Frame(txt, bg="Light Grey")
        conpassf.pack()

        self.showconpass = PhotoImage(file='Resource/showpass.png')
        self.showcon = Button(conpassf, image=self.showconpass, bd=1, command=self.showconpas)
        self.showcon.pack(side='right')
        self.__y = True
        self.__conpass = Entry(conpassf, bg="White", fg="Black", font=("", 15), show='*', width=17)
        self.__conpass.pack(side='right')

        self.__copasemt = Label(txt, bg="Light Grey")
        self.__copasemt.pack()

        btn = Frame(mainf, bg="Light Grey")
        btn.pack(expand=True)

        reg = Button(btn, text="Register", command=self.create, bd=0)
        reg.pack(side="left", padx=30)

        log = Button(btn, text="Login", command=self.__controller.log, bd=0)
        log.pack(side="right")

        aha = Label(btn, text="Already have an account", bg="Light Grey", fg="Black")
        aha.pack(side="right", padx=10)
        
        self.__window.bind('<Return>', self.callcreate)
        
    # calling the create method
    def callcreate(self, _):
        self.create()
        

    # determining the day to show
    def determine(self, _):
        if self.__yearvar.get() == 'Year':
            showinfo("Message", "Select a Year First")
            self.month.set('Month')
        match self.__monthvar.get():

            case "January":
                self.day.config(values=list(range(1, 32)))

            case "February":
                if int(self.__yearvar.get()) % 400 == 0:
                    self.day.config(values=list(range(1, 30)))

                else:
                    self.day.config(values=list(range(1, 29)))

            case "March":
                self.day.config(values=list(range(1, 32)))

            case "April":
                self.day.config(values=list(range(1, 31)))

            case "May":
                self.day.config(values=list(range(1, 32)))

            case "June":
                self.day.config(values=list(range(1, 31)))

            case "July":
                self.day.config(values=list(range(1, 32)))

            case "August":
                self.day.config(values=list(range(1, 32)))

            case "September":
                self.day.config(values=list(range(1, 31)))

            case "October":
                self.day.config(values=list(range(1, 32)))

            case "November":
                self.day.config(values=list(range(1, 31)))

            case "December":
                self.day.config(values=list(range(1, 32)))

    # show and hide password
    def showpas(self):
        if self.__x:
            self.__pass.config(show='')
            self.showpass.config(file='Resource/hidepass.png')
            self.__x = False
        else:
            self.__pass.config(show='*')
            self.showpass.config(file='Resource/showpass.png')
            self.__x = True

    # show and hide confirm password
    def showconpas(self):
        if self.__y:
            self.__conpass.config(show='')
            self.showconpass.config(file='Resource/hidepass.png')
            self.__y = False
        else:
            self.__conpass.config(show='*')
            self.showconpass.config(file='Resource/showpass.png')
            self.__y = True

    # validating and creating account
    def create(self):
        if self.validate():
            if self.__mod.double(self.__email.get()):
                showinfo("Message", "Email Already Used")
            else:
                if self.__mod.create():
                    showinfo("Message", "Account Created")
                    self.__controller.log()

    # validating the data entered
    def validate(self):
        a = self.fn()
        b = self.ln()
        c = self.dob()
        d = self.gen()
        e = self.con()
        f = self.add()
        g = self.em()
        h = self.pas()
        if a and b and c and d and e and f and g and h:
            return True

    def fn(self):
        if not self.__fn.get():
            self.__fnetm.config(text="First Name Can Not Be Empty.", font=("", 10), fg="Red")
            return False
        elif not re.match(self.__nmregex, self.__fn.get()):
            self.__fnetm.config(text="Invalid First Name", font=('', 10), fg='Red')
            return False
        else:
            self.__fnetm.config(text="")
            self.__mod.setfn(self.__fn.get())
            return True

    def ln(self):
        if not self.__ln.get():
            self.__lnemt.config(text="Last Name Can Not Be Empty.", font=("", 10), fg="Red")
            return False
        elif not re.match(self.__nmregex, self.__ln.get()):
            self.__lnemt.config(text="Invalid Last Name", font=('', 10), fg='Red')
            return False
        else:
            self.__lnemt.config(text="")
            self.__mod.setln(self.__ln.get())
            return True

    def dob(self):
        if self.__dayvar.get() == 'Day':
            self.__datelb.config(text="Select Date Of Birth.", font=("", 10), fg="Red")
            self.emt.config(font=', 5')
            return False
        else:
            self.__datelb.config(text='')
            self.emt.config(font=', 1')
            date = self.__yearvar.get() + "-" + self.__monthvar.get() + "-" + self.__dayvar.get()
            self.__mod.setdate(date)
            return True

    def gen(self):
        if self.__genval.get() == '1':
            self.__gen.config(text="Select A Gender.", font=("", 10), fg="Red")
            self.emt2.config(font=', 5')
            return False
        else:
            self.__gen.config(text='')
            self.emt2.config(font=', 1')
            self.__mod.setgen(self.__genval.get())
            return True

    def con(self):
        if not self.__con.get():
            self.__conemt.config(text="Contact Can Not Be Empty.", font=('', 10), fg='Red')
            return False
        elif not re.match(self.__conregx, self.__con.get()):
            self.__conemt.config(text="Invalid Contact", font=('', 10), fg='Red')
            return False
        else:
            self.__conemt.config(text="")
            self.__mod.setcon(self.__con.get())
            return True

    def add(self):
        if not self.__add.get():
            self.addlb.config(text='Address Can Not Be Empty.', font=('', 10), fg='Red')
            return False
        else:
            self.addlb.config(text='')
            self.__mod.setadd(self.__add.get())
            return True

    def em(self):
        email = self.__email.get().lower()
        if not email:
            self.__ememt.config(text="Email Can Not Be Empty.", font=("", 10), fg="Red")
            return False
        elif not re.match(self.__emregex, email):
            self.__ememt.config(text="Enter Correct Email", font=("", 10), fg="Red")
            return False
        else:
            self.__ememt.config(text="")
            self.__mod.setem(email)
            return True

    def pas(self):
        if not self.__pass.get():
            self.__pasemt.config(text="Password Can Not Be Empty.", font=("", 10), fg="Red")
            return False
        elif not re.match(self.__passregex, self.__pass.get()):
            showinfo('Message', "Password must contain 8 letters, a capital letter, a small letter, a number and a "
                                "symbol")
            self.__pasemt.config(text="Invalid Password", font=("", 10), fg="Red")
            return False
        elif self.__conpass.get() != self.__pass.get():
            self.__pasemt.config(text="")
            self.__copasemt.config(text="Incorrect password.", font=("", 10), fg="Red")
            return False
        else:
            self.__copasemt.config(text="")
            self.__mod.setpas(self.__pass.get())
            return True
