"""
    Module View
    This Is A Frontend Which User Sees And Input Data
"""

# importing required modules
import re
from tkinter import *
from tkinter import ttk
from datetime import datetime
from tkinter.ttk import Combobox
from Model.TripModel import TripModel
from Model.StaffModel import StaffModel
from Model.DriverModel import DriverModel
from Model.VehicleModel import VehicleModel
from Model.CustomerModel import CustomerModel
from Model.RegistrationModel import RegistrationModel
from tkinter.messagebox import askyesno, showinfo, showerror


# creating class Admin Home
# this is admin home
class StaffHome(ttk.Frame):

    # creating frame for staff home
    def __init__(self, window, controller, stid):

        self.__stid = stid
        self.__tripmod = TripModel()
        self.__custmod = CustomerModel()
        self.__stmod = StaffModel()
        self.__dmod = DriverModel()
        self.__vmod = VehicleModel()
        self.__window = window
        self.__window.deiconify()
        self.__controller = controller
        super().__init__(self.__window)
        self.__window.geometry("1920x1080")
        self.__window.title("Admin Home")
        self.pendingdata = None
        self.alltripdata = None
        self.allcustdata = None
        self.allstaffdata = None
        self.allvehicledata = None
        self.alldriverdata = None
        self.todaytripdata = None
        self.searchcusr = None

        mainf = Frame(self.__window, bg="Light Grey")
        mainf.pack(expand=True, fill='both')

        topf = Frame(mainf, bg='Light Grey')
        topf.pack(side='top', pady=20, fill='both')

        logout = Button(topf, text='Log Out', bg='Light Grey', fg='Black', bd=0, command=self.confirm)
        logout.pack(side='right', padx=10)

        self.logo = PhotoImage(file='Resource/logo.png')
        self.show = Label(topf, image=self.logo, bd=0)
        self.show.pack(side='left', padx=10)

        title = Label(topf, text='Staff Dashboard', bg='Light Grey', fg='Black', font=("", 30))
        title.pack()

        searchcf = Frame(mainf, bg='Light Grey')
        searchcf.pack(pady=30)

        fnf = Frame(searchcf, bg='Light Grey')
        fnf.pack(side='left')

        fnlb = Label(fnf, text='Name : ', bg='Light Grey', fg='Black', font=("", 18))
        fnlb.pack(side='left', padx=10)

        self.nameentry = Entry(fnf, bg='White', fg='Black')
        self.nameentry.pack(side='right')

        emptf1 = Frame(searchcf, bg='Light Grey')
        emptf1.pack(side='left')

        Label(emptf1, bg='Light Grey').pack(padx=40)

        lnf = Frame(searchcf, bg='Light Grey')
        lnf.pack(side='left')

        lnlb = Label(lnf, text='Address : ', bg='Light Grey', fg='Black', font=("", 18))
        lnlb.pack(side='left', padx=10)

        self.addentry = Entry(lnf, bg='White', fg='Black')
        self.addentry.pack(side='right')

        emptf2 = Frame(searchcf, bg='Light Grey')
        emptf2.pack(side='left')

        Label(emptf2, bg='Light Grey').pack(padx=40)

        searchbtn = Button(searchcf, text="Search", bg='Light Grey', fg='Black', bd=0, command=self.searchc)
        searchbtn.pack(side='left')

        choosing = Frame(mainf, bg='Light Grey')
        choosing.pack(pady=30)

        tripf = Frame(choosing, bg='Light Grey')
        tripf.pack(side='left', padx=20)

        triplb = Label(tripf, text="Show Trip : ", bg='Light Grey', fg='Black', font=("", 18))
        triplb.pack(side='left', padx=10)

        tripvalue = ["All Pending", "Today's", "All"]
        self.selectedtrip = StringVar()
        choosetrip = Combobox(tripf, values=tripvalue, textvariable=self.selectedtrip, width=15, justify='center',
                              state='readonly', font=("", 15))
        choosetrip.pack()
        self.selectedtrip.set("All Pending")
        choosetrip.bind("<<ComboboxSelected>>", self.showaboutrip)

        emptf2 = Frame(choosing, bg='Light Grey')
        emptf2.pack(side='left')

        Label(emptf2, bg='Light Grey').pack(padx=80)

        allf = Frame(choosing, bg='Light Grey')
        allf.pack(side='right', padx=20)

        alllb = Label(allf, text="Show All : ", bg='Light Grey', fg='Black', font=("", 18))
        alllb.pack(side='left')

        value = ["Vehicle", "Staff", "Driver", "Customer"]
        self.selectedall = StringVar()
        all = Combobox(allf, values=value, textvariable=self.selectedall, width=15, justify='center',
                       state='readonly', font=('', 15))
        self.selectedall.set("None")
        all.pack(side='left', padx=10)
        all.bind("<<ComboboxSelected>>", self.showall)

        self.table = Frame(mainf, bg='Light Grey')
        self.table.pack(expand=True, pady=40)

        style = ttk.Style(self.table)
        # set ttk theme to "clam" which support the field background option
        style.theme_use("clam")
        style.configure("Treeview", background="White", foreground="Black")

        self.scrollbar = Scrollbar(self.table)
        self.scrollbar.pack(side='right', fill='y')

        self.pendingtable()

        adds = Frame(mainf, bg="Light Grey")
        adds.pack(side='left', expand=True, padx=20, pady=60)

        addst = Frame(adds, bg="Light Grey")
        addst.pack(anchor='center')

        addstaff = Button(addst, text="Add Staff", bg="light Grey", fg="Black", bd=0, font=("", 20),
                          command=self.addstaff)
        addstaff.pack()

        addV = Frame(mainf, bg="light Grey")
        addV.pack(side='left', padx=20, expand=True, pady=60)

        addv = Frame(addV, bg='LighT Grey')
        addv.pack(anchor='center')

        addvehicle = Button(addv, text="Add Vehicle", bg="light Grey", fg="Black", bd=0, font=("", 20),
                            command=self.addvehicle)
        addvehicle.pack()

        addD = Frame(mainf, bg="Light Grey")
        addD.pack(side='right', expand=True, pady=60)

        add = Frame(addD, bg="Light Grey")
        add.pack(anchor='center')

        addriver = Button(add, text="Add Driver", bg="light Grey", fg="Black", bd=0, font=("", 20),
                          command=self.addriver)
        addriver.pack()

    # pending trip table
    def pendingtable(self):

        self.pendingdata = ttk.Treeview(self.table, yscrollcommand=self.scrollbar.set, selectmode="extended")
        self.pendingdata.pack()

        self.scrollbar.config(command=self.pendingdata.yview)

        # defining columns
        self.pendingdata["columns"] = ("Trip ID", "Customer Name", "Pick Up Location", "Destination", "No Of Passenger",
                                       "Departure Date", "Departure Time", "Distance", "Cost", "Status")

        # formatting columns
        self.pendingdata.column("#0", width=0, stretch=NO)
        self.pendingdata.column("Trip ID", width=50, minwidth=40, anchor=W)
        self.pendingdata.column("Customer Name", width=130, minwidth=90, anchor=W)
        self.pendingdata.column("Pick Up Location", width=180, minwidth=90, anchor=W)
        self.pendingdata.column("Destination", width=180, minwidth=90, anchor=W)
        self.pendingdata.column("No Of Passenger", width=100, minwidth=90, anchor=W)
        self.pendingdata.column("Departure Date", width=180, minwidth=90, anchor=W)
        self.pendingdata.column("Departure Time", width=180, minwidth=90, anchor=W)
        self.pendingdata.column("Distance", width=80, minwidth=50, anchor=W)
        self.pendingdata.column("Cost", width=80, minwidth=50, anchor=W)
        self.pendingdata.column("Status", width=180, minwidth=90, anchor=W)

        # creating heading
        self.pendingdata.heading("#0", text='Label')
        self.pendingdata.heading("Trip ID", text="Trip Id")
        self.pendingdata.heading("Customer Name", text="Customer Name")
        self.pendingdata.heading("Pick Up Location", text="Pick Up Location")
        self.pendingdata.heading("Destination", text="Destination")
        self.pendingdata.heading("No Of Passenger", text="No Of Passenger")
        self.pendingdata.heading("Departure Date", text="Departure Date")
        self.pendingdata.heading("Departure Time", text="Departure Time")
        self.pendingdata.heading("Distance", text="Distance")
        self.pendingdata.heading("Cost", text="Cost")
        self.pendingdata.heading("Status", text="Status")

        # reading data from table
        record = self.__tripmod.pendingtrip()
        if record:

            # inserting data into table
            for data in record:
                name = data[17] + " " + data[16]
                self.pendingdata.insert("", index="end",
                                        values=(data[0], name, data[2], data[3], data[6], data[4], data[5], data[7],
                                                data[8], data[9]))

            self.pendingdata.bind('<Double-1>', self.minipendingtable)

    # creating toplevel
    def minipendingtable(self, event):
        tripd = None
        try:
            if self.pendingdata.selection()[0]:
                for data in self.pendingdata.selection():
                    value = self.pendingdata.item(data)
                    tripd = value['values']
                tp = Toplevel()

                # always top
                tp.transient(self.__window)
                tp.grab_set()
                self.pendingdetails(tp, tripd)
        except Exception as e:
            showinfo("Message", "Select A Data")
            print(e)

    # full detailed
    def pendingdetails(self, tp, tripd):
        top = tp
        top.geometry("560x480+400+200")
        top.title("Trip Details")

        mainf = Frame(top, bg='White')
        mainf.pack(fill='both', expand=True)

        titlef = Frame(mainf, bg="White")
        titlef.pack(pady=20)

        titlelb = Label(titlef, text='Trip Details', bg='White', fg='Black', font=("", 25, 'bold'))
        titlelb.pack()

        custnamef = Frame(mainf, bg='White')
        custnamef.pack(pady=15)

        custnamelb = Label(custnamef, text='Customer Name : ', bg='White', fg='Black', font=("", 18))
        custnamelb.pack(side='left', padx=10)

        custnamedata = Label(custnamef, text=tripd[1], bg='White', fg='Black', font=("", 15))
        custnamedata.pack(side='left')

        locationf = Frame(mainf, bg='White')
        locationf.pack(pady=15)

        pickf = Frame(locationf, bg='White')
        pickf.pack(side='left', padx=20)

        picklb = Label(pickf, text='Pickup Location', bg='White', fg='Black', font=("", 18))
        picklb.pack(side='left', padx=10)

        pickdata = Label(pickf, text=tripd[2], bg='White', fg='Black', font=("", 15))
        pickdata.pack(side='left')

        dropf = Frame(locationf, bg='White')
        dropf.pack(side='right', padx=20)

        droplb = Label(dropf, text='Destination : ', bg='White', fg='Black', font=("", 18))
        droplb.pack(side='left')

        dropdata = Label(dropf, text=tripd[3], bg='White', fg='Black', font=("", 15))
        dropdata.pack(side='left', padx=10)

        datime = Frame(mainf, bg='White')
        datime.pack(pady=15)

        datef = Frame(datime, bg='White')
        datef.pack(side='left', padx=20)

        datelb = Label(datef, text='Trip Date : ', bg='White', fg='Black', font=("", 18))
        datelb.pack(side='left', padx=10)

        datedata = Label(datef, text=tripd[5], bg='White', fg='Black', font=("", 15))
        datedata.pack(side='left')

        timef = Frame(datime, bg='White')
        timef.pack(side='right', padx=20)

        timelb = Label(timef, text='Pick Up : ', bg='White', fg='Black', font=("", 18))
        timelb.pack(side='left')

        timedata = Label(timef, text=tripd[6], bg='White', fg='Black', font=("", 15))
        timedata.pack(side='left', padx=10)

        passtatus = Frame(mainf, bg='White')
        passtatus.pack(pady=15)

        passf = Frame(passtatus, bg='White')
        passf.pack(side='left', padx=20)

        passlb = Label(passf, text='No Of Passenger : ', bg='White', fg='Black', font=("", 18))
        passlb.pack(side='left', padx=10)

        passdata = Label(passf, text=tripd[4], fg='Black', bg='White', font=("", 15))
        passdata.pack(side='left')

        statusf = Frame(passtatus, bg='White')
        statusf.pack(side='right', padx=20)

        statuslb = Label(statusf, text='Status : ', bg='White', fg='Black', font=("", 18))
        statuslb.pack(side='left')

        statusdata = Label(statusf, text=tripd[9], bg='White', fg='Black', font=("", 15))
        statusdata.pack(side='left', padx=10)

        distcost = Frame(mainf, bg='White')
        distcost.pack(pady=15)

        distf = Frame(distcost, bg='White')
        distf.pack(side='left', padx=20)

        distlb = Label(distf, text="Distance : ", bg='White', fg='Black', font=("", 18))
        distlb.pack(side='left', padx=10)

        distdata = Label(distf, text=tripd[7], bg='White', fg='Black', font=("", 15))
        distdata.pack(side='left')

        costf = Frame(distcost, bg='White')
        costf.pack(side='left', padx=20)

        costlb = Label(costf, text='Cost : ', bg='White', fg='Black', font=("", 18))
        costlb.pack(side='left')

        costdata = Label(costf, text=tripd[8], bg='White', fg='Black', font=("", 15))
        costdata.pack(side='left', padx=10)

        assignf = Frame(mainf, bg='White')
        assignf.pack(pady=15)

        assignlb = Label(assignf, text='Assign Driver', bg='White', fg='Black', font=("", 18))
        assignlb.pack(side='left', padx=20)

        named = []
        record = self.__dmod.emptydriver(tripd[5])
        if record:
            for data in record:
                name = data[2] + " " + data[1]
                named.insert(0, name)
        if not named:
            named.insert(0, "No Driver Available")
        driver = StringVar()
        driver.set("Driver's Name")
        assign = ttk.Combobox(assignf, values=named, textvariable=driver, font=("", 15), state='readonly')
        assign.pack(side='left', padx=10)

        btn = Frame(mainf, bg='White')
        btn.pack(pady=10)

        assignbtn = Button(btn, text='Confirm Assign', bd=0, command=lambda: assignd())
        assignbtn.pack()

        def assignd():
            did = None
            if not driver.get() or driver.get() == "Driver's Name" or driver.get() == "No Driver Available":
                showerror('Invalid', "Select A Driver")
            else:
                driverids = self.__dmod.getid(driver.get())
                for data in driverids:
                    did = data[0]
                if self.__tripmod.assigndr(self.__stid, did, tripd[0]):
                    showinfo("Message", "Driver Assigned Successfully.")
                    top.destroy()
                    self.pendingdata.destroy()
                    self.pendingtable()

    # all trip table
    def alltriptable(self):

        self.alltripdata = ttk.Treeview(self.table, yscrollcommand=self.scrollbar.set, selectmode="extended")
        self.alltripdata.pack()

        self.scrollbar.config(command=self.alltripdata.yview)

        # defining columns
        self.alltripdata["columns"] = ("Trip ID", "Customer Name", "Pick Up Location", "Destination", "No Of Passenger",
                                       "Departure Date", "Departure Time", "Distance", "Cost", "Status", "Driver Id")

        # formatting columns
        self.alltripdata.column("#0", width=0, stretch=NO)
        self.alltripdata.column("Trip ID", width=50, minwidth=40, anchor=W)
        self.alltripdata.column("Customer Name", width=130, minwidth=90, anchor=W)
        self.alltripdata.column("Pick Up Location", width=160, minwidth=90, anchor=W)
        self.alltripdata.column("Destination", width=160, minwidth=90, anchor=W)
        self.alltripdata.column("No Of Passenger", width=100, minwidth=90, anchor=W)
        self.alltripdata.column("Departure Date", width=160, minwidth=90, anchor=W)
        self.alltripdata.column("Departure Time", width=160, minwidth=90, anchor=W)
        self.alltripdata.column("Distance", width=80, minwidth=50, anchor=W)
        self.alltripdata.column("Cost", width=80, minwidth=50, anchor=W)
        self.alltripdata.column("Status", width=180, minwidth=90, anchor=W)
        self.alltripdata.column("Driver Id", width=80, minwidth=50, anchor=W)

        # creating heading
        self.alltripdata.heading("#0", text='Label')
        self.alltripdata.heading("Trip ID", text="Trip Id")
        self.alltripdata.heading("Customer Name", text="Customer Name")
        self.alltripdata.heading("Pick Up Location", text="Pick Up Location")
        self.alltripdata.heading("Destination", text="Destination")
        self.alltripdata.heading("No Of Passenger", text="No Of Passenger")
        self.alltripdata.heading("Departure Date", text="Departure Date")
        self.alltripdata.heading("Departure Time", text="Departure Time")
        self.alltripdata.heading("Distance", text="Distance")
        self.alltripdata.heading("Cost", text="Cost")
        self.alltripdata.heading("Status", text="Status")
        self.alltripdata.heading("Driver Id", text="Driver Id")

        # reading data from table
        record = self.__tripmod.alltrip()
        if record:

            # inserting data into table
            for data in record:
                name = data[17] + " " + data[16]
                self.alltripdata.insert("", index="end",
                                        values=(data[0], name, data[2], data[3], data[6], data[4], data[5], data[7],
                                                data[8], data[9], data[14]))

        self.alltripdata.bind('<Double-1>', self.minialltrip)

    # creating toplevel
    def minialltrip(self, event):
        tripd = None
        try:
            if self.alltripdata.selection()[0]:
                for data in self.alltripdata.selection():
                    value = self.alltripdata.item(data)
                    tripd = value['values']
                tp = Toplevel()

                # always top
                tp.transient(self.__window)
                tp.grab_set()
                self.alltripdetails(tp, tripd)
        except Exception as e:
            showinfo("Message", "Select A Data")
            print(e)

    # full detailed
    def alltripdetails(self, tp, tripd):
        top = tp
        top.title("Trip Details")
        top.geometry("560x480+400+200")

        mainf = Frame(top, bg='White')
        mainf.pack(fill='both', expand=True)

        titlef = Frame(mainf, bg="White")
        titlef.pack(pady=20)

        titlelb = Label(titlef, text='Trip Details', bg='White', fg='Black', font=("", 25, 'bold'))
        titlelb.pack()

        custnamef = Frame(mainf, bg='White')
        custnamef.pack(pady=15)

        custnamelb = Label(custnamef, text='Customer Name : ', bg='White', fg='Black', font=("", 18))
        custnamelb.pack(side='left', padx=10)

        custnamedata = Label(custnamef, text=tripd[1], bg='White', fg='Black', font=("", 15))
        custnamedata.pack(side='left')

        locationf = Frame(mainf, bg='White')
        locationf.pack(pady=15)

        pickf = Frame(locationf, bg='White')
        pickf.pack(side='left', padx=20)

        picklb = Label(pickf, text='Pickup Location', bg='White', fg='Black', font=("", 18))
        picklb.pack(side='left', padx=10)

        pickdata = Label(pickf, text=tripd[2], bg='White', fg='Black', font=("", 15))
        pickdata.pack(side='left')

        dropf = Frame(locationf, bg='White')
        dropf.pack(side='right', padx=20)

        droplb = Label(dropf, text='Destination : ', bg='White', fg='Black', font=("", 18))
        droplb.pack(side='left')

        dropdata = Label(dropf, text=tripd[3], bg='White', fg='Black', font=("", 15))
        dropdata.pack(side='left', padx=10)

        datime = Frame(mainf, bg='White')
        datime.pack(pady=15)

        datef = Frame(datime, bg='White')
        datef.pack(side='left', padx=20)

        datelb = Label(datef, text='Trip Date : ', bg='White', fg='Black', font=("", 18))
        datelb.pack(side='left', padx=10)

        datedata = Label(datef, text=tripd[5], bg='White', fg='Black', font=("", 15))
        datedata.pack(side='left')

        timef = Frame(datime, bg='White')
        timef.pack(side='right', padx=20)

        timelb = Label(timef, text='Pick Up : ', bg='White', fg='Black', font=("", 18))
        timelb.pack(side='left')

        timedata = Label(timef, text=tripd[6], bg='White', fg='Black', font=("", 15))
        timedata.pack(side='left', padx=10)

        passtatus = Frame(mainf, bg='White')
        passtatus.pack(pady=15)

        passf = Frame(passtatus, bg='White')
        passf.pack(side='left', padx=20)

        passlb = Label(passf, text='No Of Passenger : ', bg='White', fg='Black', font=("", 18))
        passlb.pack(side='left', padx=10)

        passdata = Label(passf, text=tripd[4], fg='Black', bg='White', font=("", 15))
        passdata.pack(side='left')

        statusf = Frame(passtatus, bg='White')
        statusf.pack(side='right', padx=20)

        statuslb = Label(statusf, text='Status : ', bg='White', fg='Black', font=("", 18))
        statuslb.pack(side='left')

        statusdata = Label(statusf, text=tripd[9], bg='White', fg='Black', font=("", 15))
        statusdata.pack(side='left', padx=10)

        distcost = Frame(mainf, bg='White')
        distcost.pack(pady=15)

        distf = Frame(distcost, bg='White')
        distf.pack(side='left', padx=20)

        distlb = Label(distf, text="Distance : ", bg='White', fg='Black', font=("", 18))
        distlb.pack(side='left', padx=10)

        distdata = Label(distf, text=tripd[7], bg='White', fg='Black', font=("", 15))
        distdata.pack(side='left')

        costf = Frame(distcost, bg='White')
        costf.pack(side='left', padx=20)

        costlb = Label(costf, text='Cost : ', bg='White', fg='Black', font=("", 18))
        costlb.pack(side='left')

        costdata = Label(costf, text=tripd[8], bg='White', fg='Black', font=("", 15))
        costdata.pack(side='left', padx=10)
        assignf = None
        if tripd[9] == "Pending":
            assignf = Frame(mainf, bg='White')
            assignf.pack(pady=15)

            assignlb = Label(assignf, text='Assign Driver', bg='White', fg='Black', font=("", 18))
            assignlb.pack(side='left', padx=20)

            named = []
            record = self.__dmod.emptydriver(tripd[5])
            if record:
                for data in record:
                    name = data[2] + " " + data[1]
                    named.insert(0, name)
            driver = StringVar()
            driver.set("Driver's Name")
            if not named:
                named.insert(0, "No Driver Available")
            assign = ttk.Combobox(assignf, values=named, textvariable=driver, font=("", 15), state='readonly')
            assign.pack(side='left', padx=10)

            btn = Frame(mainf, bg='White')
            btn.pack(pady=10)

            assignbtn = Button(btn, text='Confirm Assign', bd=0, command=lambda: assignd())
            assignbtn.pack()
        else:
            if assignf:
                assignf.destroy()

        def assignd():
            did = None
            if not driver.get() or driver.get() == "Driver's Name" or driver.get() == "No Driver Available":
                showerror('Invalid', "Select A Driver")
            else:
                driverids = self.__dmod.getid(driver.get())
                for data in driverids:
                    did = data[0]
                if self.__tripmod.assigndr(self.__stid, did, tripd[0]):
                    showinfo("Message", "Driver Assigned Successfully.")
                    top.destroy()
                    self.alltripdata.destroy()
                    self.alltriptable()

    # today trip table
    def todaytriptable(self):

        self.todaytripdata = ttk.Treeview(self.table, yscrollcommand=self.scrollbar.set, selectmode="extended")
        self.todaytripdata.pack()

        self.scrollbar.config(command=self.todaytripdata.yview)

        # defining columns
        self.todaytripdata["columns"] = (
            "Trip ID", "Customer Name", "Pick Up Location", "Destination", "No Of Passenger",
            "Departure Date", "Departure Time", "Status", "Cost", "Driver Id")

        # formatting columns
        self.todaytripdata.column("#0", width=0, stretch=NO)
        self.todaytripdata.column("Trip ID", width=80, minwidth=90, anchor=W)
        self.todaytripdata.column("Customer Name", width=140, minwidth=90, anchor=W)
        self.todaytripdata.column("Pick Up Location", width=180, minwidth=90, anchor=W)
        self.todaytripdata.column("Destination", width=180, minwidth=90, anchor=W)
        self.todaytripdata.column("No Of Passenger", width=100, minwidth=90, anchor=W)
        self.todaytripdata.column("Departure Date", width=180, minwidth=90, anchor=W)
        self.todaytripdata.column("Departure Time", width=180, minwidth=90, anchor=W)
        self.todaytripdata.column("Status", width=180, minwidth=90, anchor=W)
        self.todaytripdata.column("Cost", width=80, minwidth=90, anchor=W)
        self.todaytripdata.column("Driver Id", width=80, minwidth=90, anchor=W)

        # creating heading
        self.todaytripdata.heading("#0", text='Label')
        self.todaytripdata.heading("Trip ID", text="Trip Id")
        self.todaytripdata.heading("Customer Name", text="Customer Name")
        self.todaytripdata.heading("Pick Up Location", text="Pick Up Location")
        self.todaytripdata.heading("Destination", text="Destination")
        self.todaytripdata.heading("No Of Passenger", text="No Of Passenger")
        self.todaytripdata.heading("Departure Date", text="Departure Date")
        self.todaytripdata.heading("Departure Time", text="Departure Time")
        self.todaytripdata.heading("Status", text="Status")
        self.todaytripdata.heading("Cost", text="Cost")
        self.todaytripdata.heading("Driver Id", text="Driver Id")

        # reading data from table
        record = self.__tripmod.todaytrip()
        if record:

            # inserting data into table
            for data in record:
                name = data[17] + " " + data[16]
                self.todaytripdata.insert("", index="end",
                                          values=(data[0], name, data[2], data[3], data[6], data[4], data[5], data[7],
                                                  data[8], data[9], data[14]))

        self.todaytripdata.bind('<Double-1>', self.minitodaytrip)

    def minitodaytrip(self, event):
        tripd = None
        try:
            if self.todaytripdata.selection()[0]:
                for data in self.todaytripdata.selection():
                    value = self.todaytripdata.item(data)
                    tripd = value['values']
                tp = Toplevel()

                # always top
                tp.transient(self.__window)
                tp.grab_set()
                self.todaytripdetails(tp, tripd)
        except Exception as e:
            showinfo("Message", "Select A Data")
            print(e)

    def todaytripdetails(self, tp, tripd):
        top = tp
        top.title("Trip Details")
        top.geometry("560x480+400+200")

        mainf = Frame(top, bg='White')
        mainf.pack(fill='both', expand=True)

        titlef = Frame(mainf, bg="White")
        titlef.pack(pady=20)

        titlelb = Label(titlef, text='Trip Details', bg='White', fg='Black', font=("", 25, 'bold'))
        titlelb.pack()

        custnamef = Frame(mainf, bg='White')
        custnamef.pack(pady=15)

        custnamelb = Label(custnamef, text='Customer Name : ', bg='White', fg='Black', font=("", 18))
        custnamelb.pack(side='left', padx=10)

        custnamedata = Label(custnamef, text=tripd[1], bg='White', fg='Black', font=("", 15))
        custnamedata.pack(side='left')

        locationf = Frame(mainf, bg='White')
        locationf.pack(pady=15)

        pickf = Frame(locationf, bg='White')
        pickf.pack(side='left', padx=20)

        picklb = Label(pickf, text='Pickup Location', bg='White', fg='Black', font=("", 18))
        picklb.pack(side='left', padx=10)

        pickdata = Label(pickf, text=tripd[2], bg='White', fg='Black', font=("", 15))
        pickdata.pack(side='left')

        dropf = Frame(locationf, bg='White')
        dropf.pack(side='right', padx=20)

        droplb = Label(dropf, text='Destination : ', bg='White', fg='Black', font=("", 18))
        droplb.pack(side='left')

        dropdata = Label(dropf, text=tripd[3], bg='White', fg='Black', font=("", 15))
        dropdata.pack(side='left', padx=10)

        datime = Frame(mainf, bg='White')
        datime.pack(pady=15)

        datef = Frame(datime, bg='White')
        datef.pack(side='left', padx=20)

        datelb = Label(datef, text='Trip Date : ', bg='White', fg='Black', font=("", 18))
        datelb.pack(side='left', padx=10)

        datedata = Label(datef, text=tripd[5], bg='White', fg='Black', font=("", 15))
        datedata.pack(side='left')

        timef = Frame(datime, bg='White')
        timef.pack(side='right', padx=20)

        timelb = Label(timef, text='Pick Up : ', bg='White', fg='Black', font=("", 18))
        timelb.pack(side='left')

        timedata = Label(timef, text=tripd[6], bg='White', fg='Black', font=("", 15))
        timedata.pack(side='left', padx=10)

        passtatus = Frame(mainf, bg='White')
        passtatus.pack(pady=15)

        passf = Frame(passtatus, bg='White')
        passf.pack(side='left', padx=20)

        passlb = Label(passf, text='No Of Passenger : ', bg='White', fg='Black', font=("", 18))
        passlb.pack(side='left', padx=10)

        passdata = Label(passf, text=tripd[4], fg='Black', bg='White', font=("", 15))
        passdata.pack(side='left')

        statusf = Frame(passtatus, bg='White')
        statusf.pack(side='right', padx=20)

        statuslb = Label(statusf, text='Status : ', bg='White', fg='Black', font=("", 18))
        statuslb.pack(side='left')

        statusdata = Label(statusf, text=tripd[9], bg='White', fg='Black', font=("", 15))
        statusdata.pack(side='left', padx=10)

        distcost = Frame(mainf, bg='White')
        distcost.pack(pady=15)

        distf = Frame(distcost, bg='White')
        distf.pack(side='left', padx=20)

        distlb = Label(distf, text="Distance : ", bg='White', fg='Black', font=("", 18))
        distlb.pack(side='left', padx=10)

        distdata = Label(distf, text=tripd[7], bg='White', fg='Black', font=("", 15))
        distdata.pack(side='left')

        costf = Frame(distcost, bg='White')
        costf.pack(side='left', padx=20)

        costlb = Label(costf, text='Cost : ', bg='White', fg='Black', font=("", 18))
        costlb.pack(side='left')

        costdata = Label(costf, text=tripd[8], bg='White', fg='Black', font=("", 15))
        costdata.pack(side='left', padx=10)
        assignf = None
        if tripd[9] == "Pending":
            assignf = Frame(mainf, bg='White')
            assignf.pack(pady=15)

            assignlb = Label(assignf, text='Assign Driver', bg='White', fg='Black', font=("", 18))
            assignlb.pack(side='left', padx=20)

            named = []
            record = self.__dmod.emptydriver(tripd[5])
            if record:
                for data in record:
                    name = data[2] + " " + data[1]
                    named.insert(0, name)
            if not named:
                named.insert(0, "No Driver Available")
            driver = StringVar()
            driver.set("Driver's Name")
            assign = ttk.Combobox(assignf, values=named, textvariable=driver, font=("", 15), state='readonly')
            assign.pack(side='left', padx=10)

            btn = Frame(mainf, bg='White')
            btn.pack(pady=10)

            assignbtn = Button(btn, text='Confirm Assign', bd=0, command=lambda: assignd())
            assignbtn.pack()
        else:
            if assignf:
                assignf.destroy()

        def assignd():
            did = None
            if not driver.get() or driver.get() == "Driver's Name" or driver.get() == "No Driver Available":
                showerror('Invalid', "Select A Driver")
            else:
                driverids = self.__dmod.getid(driver.get())
                for data in driverids:
                    did = data[0]
                if self.__tripmod.assigndr(self.__stid, did, tripd[0]):
                    showinfo("Message", "Driver Assigned Successfully.")
                    top.destroy()
                    self.todaytripdata.destroy()
                    self.todaytriptable()

    # showing all customer details
    def allcustable(self):
        self.allcustdata = ttk.Treeview(self.table, yscrollcommand=self.scrollbar.set, selectmode="extended")
        self.allcustdata.pack()

        self.scrollbar.config(command=self.allcustdata.yview)

        # defining columns
        self.allcustdata["columns"] = ("Cust ID", "Customer Name", "DOB", "Gender", "Address", "Contact", "Email")

        # formatting columns
        self.allcustdata.column("#0", width=0, stretch=NO)
        self.allcustdata.column("Cust ID", width=80, minwidth=90, anchor=W)
        self.allcustdata.column("Customer Name", width=140, minwidth=90, anchor=W)
        self.allcustdata.column("DOB", width=180, minwidth=90, anchor=W)
        self.allcustdata.column("Gender", width=180, minwidth=90, anchor=W)
        self.allcustdata.column("Address", width=100, minwidth=90, anchor=W)
        self.allcustdata.column("Contact", width=100, minwidth=90, anchor=W)
        self.allcustdata.column("Email", width=180, minwidth=90, anchor=W)

        # creating heading
        self.allcustdata.heading("#0", text='Label')
        self.allcustdata.heading("Cust ID", text="Customer Id")
        self.allcustdata.heading("Customer Name", text="Customer Name")
        self.allcustdata.heading("DOB", text="DOB")
        self.allcustdata.heading("Gender", text="Gender")
        self.allcustdata.heading("Address", text="Address")
        self.allcustdata.heading("Contact", text="Contact")
        self.allcustdata.heading("Email", text="Email")

        # reading data from table
        record = self.__custmod.allcust()
        if record:

            # inserting data into table
            for data in record:
                name = data[2] + " " + data[1]
                self.allcustdata.insert("", index="end",
                                        values=(data[0], name, data[3], data[4], data[5], data[6], data[7]))

    # showing all staff details
    def allstafftable(self):
        self.allstaffdata = ttk.Treeview(self.table, yscrollcommand=self.scrollbar.set, selectmode="extended")
        self.allstaffdata.pack()

        self.scrollbar.config(command=self.allstaffdata.yview)

        # defining columns
        self.allstaffdata["columns"] = ("Staff ID", "Staff Name", "DOB", "Gender", "Address", "Contact", "Email")

        # formatting columns
        self.allstaffdata.column("#0", width=0, stretch=NO)
        self.allstaffdata.column("Staff ID", width=80, minwidth=90, anchor=W)
        self.allstaffdata.column("Staff Name", width=140, minwidth=90, anchor=W)
        self.allstaffdata.column("DOB", width=180, minwidth=90, anchor=W)
        self.allstaffdata.column("Gender", width=180, minwidth=90, anchor=W)
        self.allstaffdata.column("Address", width=100, minwidth=90, anchor=W)
        self.allstaffdata.column("Contact", width=100, minwidth=90, anchor=W)
        self.allstaffdata.column("Email", width=180, minwidth=90, anchor=W)

        # creating heading
        self.allstaffdata.heading("#0", text='Label')
        self.allstaffdata.heading("Staff ID", text="Staff Id")
        self.allstaffdata.heading("Staff Name", text="Staff Name")
        self.allstaffdata.heading("DOB", text="DOB")
        self.allstaffdata.heading("Gender", text="Gender")
        self.allstaffdata.heading("Address", text="Address")
        self.allstaffdata.heading("Contact", text="Contact")
        self.allstaffdata.heading("Email", text="Email")

        # reading data from table
        record = self.__stmod.allstaff()
        if record:

            # inserting data into table
            for data in record:
                name = data[2] + " " + data[1]
                self.allstaffdata.insert("", index="end",
                                         values=(data[0], name, data[3], data[4], data[5], data[6], data[7]))

    # showing all driver details
    def alldrivertable(self):
        self.alldriverdata = ttk.Treeview(self.table, yscrollcommand=self.scrollbar.set, selectmode="extended")
        self.alldriverdata.pack()

        self.scrollbar.config(command=self.alldriverdata.yview)

        # defining columns
        self.alldriverdata["columns"] = ("Driver ID", "Driver Name", "DOB", "Gender", "Address", "Contact", "License No"
                                         , "Email")

        # formatting columns
        self.alldriverdata.column("#0", width=0, stretch=NO)
        self.alldriverdata.column("Driver ID", width=80, minwidth=90, anchor=W)
        self.alldriverdata.column("Driver Name", width=140, minwidth=90, anchor=W)
        self.alldriverdata.column("DOB", width=180, minwidth=90, anchor=W)
        self.alldriverdata.column("Gender", width=180, minwidth=90, anchor=W)
        self.alldriverdata.column("Address", width=100, minwidth=90, anchor=W)
        self.alldriverdata.column("Contact", width=100, minwidth=90, anchor=W)
        self.alldriverdata.column("License No", width=100, minwidth=90, anchor=W)
        self.alldriverdata.column("Email", width=180, minwidth=90, anchor=W)

        # creating heading
        self.alldriverdata.heading("#0", text='Label')
        self.alldriverdata.heading("Driver ID", text="Driver Id")
        self.alldriverdata.heading("Driver Name", text="Driver Name")
        self.alldriverdata.heading("DOB", text="DOB")
        self.alldriverdata.heading("Gender", text="Gender")
        self.alldriverdata.heading("Address", text="Address")
        self.alldriverdata.heading("Contact", text="Contact")
        self.alldriverdata.heading("License No", text="License No")
        self.alldriverdata.heading("Email", text="Email")

        # reading data from table
        record = self.__dmod.alldriver()
        if record:

            # inserting data into table
            for data in record:
                name = data[2] + " " + data[1]
                self.alldriverdata.insert("", index="end",
                                          values=(data[0], name, data[3], data[4], data[5], data[6], data[7], data[8]))

            # self.pendingdata.bind('<Double-1>', self.data)

    # showing all vehicle details
    def allvehicletable(self):
        self.allvehicledata = ttk.Treeview(self.table, yscrollcommand=self.scrollbar.set, selectmode="extended")
        self.allvehicledata.pack()

        self.scrollbar.config(command=self.allvehicledata.yview)

        # defining columns
        self.allvehicledata["columns"] = ("Vehicle ID", "Vehicle No", "Vehicle Type", "Vehicle Model", "Date Registered"
                                          , "Status")

        # formatting columns
        self.allvehicledata.column("#0", width=0, stretch=NO)
        self.allvehicledata.column("Vehicle ID", width=100, minwidth=50, anchor=W)
        self.allvehicledata.column("Vehicle No", width=180, minwidth=90, anchor=W)
        self.allvehicledata.column("Vehicle Type", width=180, minwidth=90, anchor=W)
        self.allvehicledata.column("Vehicle Model", width=180, minwidth=90, anchor=W)
        self.allvehicledata.column("Date Registered", width=180, minwidth=90, anchor=W)
        self.allvehicledata.column("Status", width=180, minwidth=90, anchor=W)

        # creating heading
        self.allvehicledata.heading("#0", text='Label')
        self.allvehicledata.heading("Vehicle ID", text="Vehicle ID")
        self.allvehicledata.heading("Vehicle No", text="Vehicle No")
        self.allvehicledata.heading("Vehicle Type", text="Vehicle Type")
        self.allvehicledata.heading("Vehicle Model", text="Vehicle Model")
        self.allvehicledata.heading("Date Registered", text="Date Registered")
        self.allvehicledata.heading("Status", text="Status")

        # reading data from table
        record = self.__vmod.allvehicle()
        if record:

            # inserting data into table
            for data in record:
                self.allvehicledata.insert("", index="end",
                                           values=(data[0], data[1], data[2], data[3], data[4], data[6]))

    def showaboutrip(self, _):
        self.nameentry.delete(0, 'end')
        self.addentry.delete(0, 'end')
        self.selectedall.set("None")
        if self.pendingdata:
            self.pendingdata.destroy()
        if self.alltripdata:
            self.alltripdata.destroy()
        if self.todaytripdata:
            self.todaytripdata.destroy()
        if self.allcustdata:
            self.allcustdata.destroy()
        if self.allstaffdata:
            self.allstaffdata.destroy()
        if self.alldriverdata:
            self.alldriverdata.destroy()
        if self.allvehicledata:
            self.allvehicledata.destroy()
        if self.searchcusr:
            self.searchcusr.destroy()
        if self.selectedtrip.get() == "All Pending":
            self.pendingtable()
        if self.selectedtrip.get() == "Today's":
            self.todaytriptable()
        if self.selectedtrip.get() == "All":
            self.alltriptable()

    # showing table according to selected
    def showall(self, _):
        self.nameentry.delete(0, 'end')
        self.addentry.delete(0, 'end')
        self.selectedtrip.set("None")
        if self.pendingdata:
            self.pendingdata.destroy()
        if self.alltripdata:
            self.alltripdata.destroy()
        if self.todaytripdata:
            self.todaytripdata.destroy()
        if self.allcustdata:
            self.allcustdata.destroy()
        if self.allstaffdata:
            self.allstaffdata.destroy()
        if self.alldriverdata:
            self.alldriverdata.destroy()
        if self.allvehicledata:
            self.allvehicledata.destroy()
        if self.searchcusr:
            self.searchcusr.destroy()
        if self.selectedall.get() == "Customer":
            self.allcustable()
        elif self.selectedall.get() == "Staff":
            self.allstafftable()
        elif self.selectedall.get() == "Driver":
            self.alldrivertable()
        elif self.selectedall.get() == "Vehicle":
            self.allvehicletable()

    # searching customer from name
    def searchc(self):
        self.selectedall.set("None")
        self.selectedtrip.set("None")
        if self.pendingdata:
            self.pendingdata.destroy()
        if self.alltripdata:
            self.alltripdata.destroy()
        if self.todaytripdata:
            self.todaytripdata.destroy()
        if self.allcustdata:
            self.allcustdata.destroy()
        if self.allstaffdata:
            self.allstaffdata.destroy()
        if self.alldriverdata:
            self.alldriverdata.destroy()
        if self.allvehicledata:
            self.allvehicledata.destroy()
        if self.searchcusr:
            self.searchcusr.destroy()
        if not self.nameentry.get():
            name = None
        else:
            name = self.nameentry.get()
        if not self.addentry.get():
            add = None
        else:
            add = self.addentry.get()
        self.nameentry.delete(0, 'end')
        self.addentry.delete(0, 'end')
        record = self.__custmod.search(name, add)
        self.searchcust(record)

    def searchcust(self, rcrd):
        self.searchcusr = ttk.Treeview(self.table, yscrollcommand=self.scrollbar.set, selectmode="extended")
        self.searchcusr.pack()

        self.scrollbar.config(command=self.searchcusr.yview)

        # defining columns
        self.searchcusr["columns"] = ("Cust ID", "Customer Name", "DOB", "Gender", "Address", "Contact", "Email")

        # formatting columns
        self.searchcusr.column("#0", width=0, stretch=NO)
        self.searchcusr.column("Cust ID", width=80, minwidth=90, anchor=W)
        self.searchcusr.column("Customer Name", width=140, minwidth=90, anchor=W)
        self.searchcusr.column("DOB", width=180, minwidth=90, anchor=W)
        self.searchcusr.column("Gender", width=180, minwidth=90, anchor=W)
        self.searchcusr.column("Address", width=100, minwidth=90, anchor=W)
        self.searchcusr.column("Contact", width=100, minwidth=90, anchor=W)
        self.searchcusr.column("Email", width=180, minwidth=90, anchor=W)

        # creating heading
        self.searchcusr.heading("#0", text='Label')
        self.searchcusr.heading("Cust ID", text="Customer Id")
        self.searchcusr.heading("Customer Name", text="Customer Name")
        self.searchcusr.heading("DOB", text="DOB")
        self.searchcusr.heading("Gender", text="Gender")
        self.searchcusr.heading("Address", text="Address")
        self.searchcusr.heading("Contact", text="Contact")
        self.searchcusr.heading("Email", text="Email")

        record = rcrd
        if record:

            # inserting data into table
            for data in record:
                name = data[2] + " " + data[1]
                self.searchcusr.insert("", index="end",
                                       values=(data[0], name, data[3], data[4], data[5], data[6], data[7]))

    # top level to add staff
    def addstaff(self):
        add = Toplevel()

        # always top
        add.transient(self.__window)
        add.grab_set()
        AddStaff(add)

    # top level to add vehicle
    def addvehicle(self):
        add = Toplevel()

        # always top
        add.transient(self.__window)
        add.grab_set()
        AddVehicle(add)

    # top level to add driver
    def addriver(self):
        add = Toplevel()

        # always top
        add.transient(self.__window)
        add.grab_set()
        AddDriver(add)

    # confirming log out
    def confirm(self):
        ans = askyesno("Conformation", "Are You Sure You Want To Log Out?")
        if ans:
            self.__controller.log()


# declaring class add staff
class AddStaff:

    # creating a top level to be displayed over root window
    def __init__(self, window):

        self.__stmod = StaffModel()
        self.__window = window
        self.__window.title("Add Staff")
        self.__window.geometry('440x525+500+200')
        self.__nmregex = ("[A-Z][a-z]{2,10}")  # firstname, lastname regex
        self.__conregx = ("[9]{1}[\d]{9}")  # contact regex
        self.__emregex = ('^[a-z0-9]+[\._]?[a-z0-9]+[@]\w+[.]\w{2,3}$')  # regex for email only
        self.__passregex = ("^.*(?=.{8,})(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).*$")  # regex for password only

        mainf = Frame(self.__window, bg='Light Grey')
        mainf.pack(expand=True, fill='both')

        title = Frame(mainf, bg='Light Grey')
        title.pack(expand=True)

        titlelb = Label(title, text='Add Staff', bg='Light Grey', fg='Black', font=("", 20, 'bold'))
        titlelb.pack(pady=20)

        lbtx = Frame(mainf, bg='Light Grey')
        lbtx.pack(expand=True)

        lb = Frame(lbtx, bg='Light Grey')
        lb.pack(side='left', padx=30)

        stname = Label(lb, text='First Name', bg='Light Grey', fg='Black', font=("", 18))
        stname.pack()

        Label(lb, bg='Light Grey').pack()

        stlname = Label(lb, text='Last Name', bg='Light Grey', fg='Black', font=("", 18))
        stlname.pack()

        Label(lb, bg='Light Grey').pack()

        stdob = Label(lb, text='Date of Birth', bg='Light Grey', fg='Black', font=("", 18))
        stdob.pack()

        Label(lb, bg='Light Grey').pack()

        stgender = Label(lb, text='Gender', bg='Light Grey', fg='Black', font=("", 18))
        stgender.pack()

        Label(lb, bg='Light Grey').pack()

        stadd = Label(lb, text='Address', bg='Light Grey', fg='Black', font=("", 18))
        stadd.pack()

        Label(lb, bg='Light Grey').pack()

        stcon = Label(lb, text='Contact', bg='Light Grey', fg='Black', font=("", 18))
        stcon.pack()

        Label(lb, bg='Light Grey').pack()

        stemail = Label(lb, text='Email', bg='Light Grey', fg='Black', font=("", 18))
        stemail.pack()

        Label(lb, bg='Light Grey').pack()

        stpass = Label(lb, text='Password', bg='Light Grey', fg='Black', font=("", 18))
        stpass.pack()

        Label(lb, bg='Light Grey').pack()

        txt = Frame(lbtx, bg='Light Grey')
        txt.pack(side='right', padx=30)

        self.__stfname = Entry(txt, bg='White', fg='Black')
        self.__stfname.pack()

        self.__stfnlb = Label(txt, bg='Light Grey')
        self.__stfnlb.pack()

        self.__stlname = Entry(txt, bg='White', fg='Black')
        self.__stlname.pack()

        self.__stlnlb = Label(txt, bg='Light Grey')
        self.__stlnlb.pack()

        date = Frame(txt, bg="Light Grey")
        date.pack()

        # using datetime module to find the current year
        x = datetime.now()
        y = x.year - 18
        z = x.year - 100
        yea = list(range(z, y))
        self.__yearvar = StringVar()
        year = Combobox(date, values=yea, textvariable=self.__yearvar, width=4, justify="left", state='readonly')
        year.set("Year")
        year.pack(side="left")

        mon = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
               "November", "December"]
        self.__monthvar = StringVar()
        self.month = Combobox(date, values=mon, textvariable=self.__monthvar, width=7, justify="left", state='readonly')
        self.month.set("Month")
        self.month.pack(side="left", padx=2)
        self.month.bind("<<ComboboxSelected>>", self.determine)

        self.__dayvar = StringVar()
        self.day = Combobox(date, values=[], textvariable=self.__dayvar, width=3, justify="left", state='readonly')
        self.day.set("Day")
        self.day.pack(side="left")

        self.__datelb = Label(txt, bg="Light Grey")
        self.__datelb.pack()

        self.__emt = Label(txt, bg='Light Grey', font=('', 1))
        self.__emt.pack()

        radiio = Frame(txt, bg="Light Grey")
        radiio.pack()

        self.__genval = StringVar()
        self.__genval.set('1')
        self.__male = Radiobutton(radiio, text="Male", variable=self.__genval, value="Male")
        self.__male.pack(side='left')
        self.__female = Radiobutton(radiio, text="Female", variable=self.__genval, value="Female")
        self.__female.pack(side='left', padx=10)
        self.__other = Radiobutton(radiio, text="Other", variable=self.__genval, value="Others")
        self.__other.pack(side='left')

        self.__gen = Label(txt, bg="Light Grey")
        self.__gen.pack()

        self.__emt2 = Label(txt, bg='Light Grey', font=('', 1))
        self.__emt2.pack()

        self.__stadd = Entry(txt, bg='White', fg='Black')
        self.__stadd.pack()

        self.__add = Label(txt, bg='Light Grey')
        self.__add.pack()

        self.__stcon = Entry(txt, bg='White', fg='Black')
        self.__stcon.pack()

        self.__con = Label(txt, bg='Light Grey')
        self.__con.pack()

        self.__stemail = Entry(txt, bg='White', fg='Black')
        self.__stemail.pack()

        self.__stemlb = Label(txt, bg='Light Grey')
        self.__stemlb.pack()

        self.__stpass = Entry(txt, show='*', bg='White', fg='Black')
        self.__stpass.pack()

        self.__stpasslb = Label(txt, bg='Light Grey')
        self.__stpasslb.pack()

        btn = Frame(mainf, bg='Light Grey')
        btn.pack(expand=True)

        add = Button(btn, text='Add Staff', bg='Light Grey', fg='Black', bd=0, command=self.create)
        add.pack(side='left', padx=30, pady=10)

        cancel = Button(btn, text="Cancel", bg='Light Grey', fg="Black", bd=0, command=self.close)
        cancel.pack(side='right', padx=30, pady=10)

        self.__window.bind('<Return>', self.callcreate)

    # calling creating
    def callcreate(self, _):
        self.create()

    # determining the day to show
    def determine(self, _):
        if self.__yearvar.get() == 'Year':
            showinfo("Message", "Select a Year First")
            self.month.set("Month")
        match self.__monthvar.get():

            case "January":
                self.day.config(values=list(range(1, 32)))

            case "February":
                if int(self.__yearvar.get()) % 400 == 0:
                    self.day.config(values=list(range(1, 30)))

                else:
                    self.day.config(values=list(range(1, 29)))

            case "March":
                self.day.config(values=list(range(1, 32)))

            case "April":
                self.day.config(values=list(range(1, 31)))

            case "May":
                self.day.config(values=list(range(1, 32)))

            case "June":
                self.day.config(values=list(range(1, 31)))

            case "July":
                self.day.config(values=list(range(1, 32)))

            case "August":
                self.day.config(values=list(range(1, 32)))

            case "September":
                self.day.config(values=list(range(1, 31)))

            case "October":
                self.day.config(values=list(range(1, 32)))

            case "November":
                self.day.config(values=list(range(1, 31)))

            case "December":
                self.day.config(values=list(range(1, 32)))

    # validating and creating account
    def create(self):
        if self.validate():
            mod = RegistrationModel()
            if mod.double(self.__stemail.get()):
                showinfo("Message", "Email Already Used")
            else:
                if self.__stmod.create():
                    showinfo("Message", "Account Created")
                    self.__window.destroy()

    # validating the data entered
    def validate(self):
        a = self.fn()
        b = self.ln()
        c = self.dob()
        d = self.gen()
        e = self.con()
        f = self.add()
        g = self.em()
        h = self.pas()
        if a and b and c and d and e and f and g and h:
            return True

    def fn(self):
        if not self.__stfname.get():
            self.__stfnlb.config(text="First Name Can Not Be Empty.", font=("", 10), fg="Red")
            return False
        elif not re.match(self.__nmregex, self.__stfname.get()):
            self.__stfnlb.config(text="Invalid First Name", font=('', 10), fg='Red')
            return False
        else:
            self.__stfnlb.config(text="")
            self.__stmod.setfn(self.__stfname.get())
            return True

    def ln(self):
        if not self.__stlname.get():
            self.__stlnlb.config(text="Last Name Can Not Be Empty.", font=("", 10), fg="Red")
            return False
        elif not re.match(self.__nmregex, self.__stlname.get()):
            self.__stlnlb.config(text="Invalid Last Name", font=('', 10), fg='Red')
            return False
        else:
            self.__stlnlb.config(text="")
            self.__stmod.setln(self.__stlname.get())
            return True

    def dob(self):
        if self.__dayvar.get() == 'Day':
            self.__datelb.config(text="Select Date Of Birth.", font=("", 10), fg="Red")
            self.__emt.config(font=', 5')
            return False
        else:
            self.__datelb.config(text='')
            self.__emt.config(font=', 1')
            date = self.__yearvar.get() + "-" + self.__monthvar.get() + "-" + self.__dayvar.get()
            self.__stmod.setdate(date)
            return True

    def gen(self):
        if self.__genval.get() == '1':
            self.__gen.config(text="Select A Gender.", font=("", 10), fg="Red")
            self.__emt2.config(font=', 5')
            return False
        else:
            self.__gen.config(text='')
            self.__emt2.config(font=', 1')
            self.__stmod.setgen(self.__genval.get())
            return True

    def con(self):
        if not self.__stcon.get():
            self.__con.config(text="Contact Can Not Be Empty.", font=('', 10), fg='Red')
            return False
        elif not re.match(self.__conregx, self.__stcon.get()):
            self.__con.config(text="Invalid Contact", font=('', 10), fg='Red')
            return False
        else:
            self.__con.config(text="")
            self.__stmod.setcon(self.__stcon.get())
            return True

    def add(self):
        if not self.__stadd.get():
            self.__add.config(text='Address Can Not Be Empty.', font=('', 10), fg='Red')
            return False
        else:
            self.__add.config(text='')
            self.__stmod.setadd(self.__stadd.get())
            return True

    def em(self):
        email = self.__stemail.get().lower()
        if not email:
            self.__stemlb.config(text="Email Can Not Be Empty.", font=("", 10), fg="Red")
            return False
        elif not re.match(self.__emregex, email):
            self.__stemlb.config(text="Enter Correct Email", font=("", 10), fg="Red")
            return False
        else:
            self.__stemlb.config(text="")
            self.__stmod.setem(email)
            return True

    def pas(self):
        if not self.__stpass.get():
            self.__stpasslb.config(text="Password Can Not Be Empty.", font=("", 10), fg="Red")
            return False
        elif not re.match(self.__passregex, self.__stpass.get()):
            showinfo('Message', "Password must contain 8 letters, a capital letter, a small letter, a number and a "
                                "symbol")
            self.__stpasslb.config(text="Invalid Password", font=("", 10), fg="Red")
            return False
        else:
            self.__stpasslb.config(text="")
            self.__stmod.setpas(self.__stpass.get())
            return True

    # closing the top level if wrong click
    def close(self):
        self.__window.destroy()


# this is to add vehicle
class AddVehicle:

    # creating a top level to be displayed over root window
    def __init__(self, window):

        self.__vmod = VehicleModel()
        self.__window = window
        self.__window.title("Add Vehicle")
        self.__window.geometry('400x350+500+230')
        self.__numrex = ("[A-Z]{1}[a-z]{1}\s[0-9]{1,3}\s[A-Za-z]{1,3}\s[0-9]{1,5}")  # regex for number only

        mainf = Frame(self.__window, bg='Light Grey')
        mainf.pack(expand=True, fill='both')

        title = Frame(mainf, bg='Light Grey')
        title.pack(expand=True)

        titlelb = Label(title, text='Add Vehicle', bg='Light Grey', fg='Black', font=("", 20, 'bold'))
        titlelb.pack(pady=20)

        lbtx = Frame(mainf, bg='Light Grey')
        lbtx.pack(expand=True)

        lb = Frame(lbtx, bg='Light Grey')
        lb.pack(side='left', padx=20)

        self.__vehiclenolb = Label(lb, text='Vehicle No', bg='Light Grey', fg='Black', font=("", 18))
        self.__vehiclenolb.pack()

        Label(lb, bg='Light Grey').pack()

        self.__vehicletypelb = Label(lb, text='Vehicle Type', bg='Light Grey', fg='Black', font=("", 18))
        self.__vehicletypelb.pack()

        Label(lb, bg='Light Grey').pack()

        self.__vehiclemodellb = Label(lb, text='Vehicle Model', bg='Light Grey', fg='Black', font=("", 18))
        self.__vehiclemodellb.pack()

        Label(lb, bg='Light Grey').pack()
        Label(lb, bg='Light Grey').pack()

        self.__vehicledeslb = Label(lb, text='Description', bg='Light Grey', fg='Black', font=("", 18))
        self.__vehicledeslb.pack()

        Label(lb, bg='Light Grey').pack()

        txt = Frame(lbtx, bg='Light Grey')
        txt.pack(side='right', padx=20)

        self.__vehicleno = Entry(txt, bg='Light Grey', fg='Black')
        self.__vehicleno.pack()

        self.vehicleno = Label(txt, bg='Light Grey')
        self.vehicleno.pack()

        self.__vehiclet = StringVar()
        type = list(("Hundai", "Maruti", "Honda"))
        self.__vehicletype = Combobox(txt, values=type, textvariable=self.__vehiclet, state='readonly')
        self.__vehicletype.set("Select Vehicle")
        self.__vehicletype.pack()
        self.__vehicletype.bind("<<ComboboxSelected>>", self.vehicleM)
        self.vehicletype = Label(txt, bg='Light Grey')
        self.vehicletype.pack()

        self.__vehiclemod = StringVar()
        self.__vehiclemodel = Combobox(txt, values=[], textvariable=self.__vehiclemod, state='readonly')
        self.__vehiclemodel.set("Select Model")
        self.__vehiclemodel.pack()

        self.vehiclemodel = Label(txt, bg='Light Grey')
        self.vehiclemodel.pack()

        self.__vehicledes = Text(txt, width=30, height=4, bg='Light Grey', fg='Black')
        self.__vehicledes.pack()

        btn = Frame(mainf, bg='Light Grey')
        btn.pack(expand=True)

        add = Button(btn, text='Add Vehicle', bg='Light Grey', fg='Black', bd=0, command=self.addv)
        add.pack(side='left', padx=30, pady=10)

        cancel = Button(btn, text="Cancel", bg='Light Grey', fg="Black", bd=0, command=self.close)
        cancel.pack(side='right', padx=30, pady=10)

        self.__window.bind("<Return>", self.calladdv)

    # calling addv method
    def calladdv(self, _):
        self.addv()

    # setting model according to type
    def vehicleM(self, _):
        match self.__vehiclet.get():

            case "Hundai":
                self.__vehiclemodel.config(values=["Grand 110 NIOS", "Aura", "Venue"])

            case "Maruti":
                self.__vehiclemodel.config(values=["Swift dzire", "Eeco", "Ritz"])

            case "Honda":
                self.__vehiclemodel.config(values=["Amaze V", "city E", "mobilio S"])

    # add vehicle details
    def addv(self):
        if self.validate():
            if self.__vmod.double(self.__vehicleno.get()):
                showinfo('Message', "Vehicle Already Added")
            else:
                if self.__vehicledes.get("1.0", END):
                    self.__vmod.setdescription(self.__vehicledes.get("1.0", END))
                self.__vmod.addV()
                showinfo("Message", "Vehicle Added")
                self.__window.destroy()

    # validating the entered data
    def validate(self):
        a = self.vno()
        b = self.vtype()
        c = self.vmodel()
        if a and b and c:
            return True

    def vno(self):
        if not self.__vehicleno.get():
            self.vehicleno.config(text='Vehicle No Can Not Be Empty.', font=("", 10), fg="Red")
            return False
        elif not re.match(self.__numrex, self.__vehicleno.get()):
            self.vehicleno.config(text='Invalid Vehicle Number.', font=("", 10), fg="Red")
            return False
        else:
            self.vehicleno.config(text='')
            self.__vmod.setvehicleno(self.__vehicleno.get())
            return True

    def vtype(self):
        if self.__vehiclet.get() == "Select Vehicle":
            self.vehicletype.config(text='Vehicle Type Can Not Be Empty.', font=("", 10), fg="Red")
            return False
        else:
            self.vehicletype.config(text='')
            self.__vmod.setvehicletype(self.__vehiclet.get())
            return True

    def vmodel(self):
        if self.__vehiclemod.get() == "Select Model":
            self.vehiclemodel.config(text='Vehicle Model Can Not Be Empty.', font=("", 10), fg="Red")
            return False
        else:
            self.vehiclemodel.config(text='')
            self.__vmod.setvehiclemodel(self.__vehiclemod.get())
            return True

    # closing the top level if wrong click
    def close(self):
        self.__window.destroy()


# declaring class add staff
class AddDriver:

    # creating a top level to be displayed over root window
    def __init__(self, window):

        self.__dmod = DriverModel()
        self.__vmod = VehicleModel()
        self.__window = window
        self.__window.title("Add Driver")
        self.__window.geometry('480x660+500+150')
        self.__nmregex = ("[A-Z][a-z]{2,10}")  # firstname, lastname regex
        self.__conregx = ("[9]{1}[\d]{9}")  # contact regex
        self.__emregex = ("^[a-z0-9]+[\._]?[a-z0-9]+[@]\w+[.]\w{2,3}$")  # regex for email only
        self.__passregex = ("^.*(?=.{8,})(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).*$")  # regex for password only

        mainf = Frame(self.__window, bg='Light Grey')
        mainf.pack(expand=True, fill='both')

        title = Frame(mainf, bg='Light Grey')
        title.pack(expand=True)

        titlelb = Label(title, text='Add Driver', bg='Light Grey', fg='Black', font=("", 20, 'bold'))
        titlelb.pack(pady=20)

        lbtx = Frame(mainf, bg='Light Grey')
        lbtx.pack(expand=True)

        lb = Frame(lbtx, bg='Light Grey')
        lb.pack(side='left', padx=40)

        dfname = Label(lb, text='First Name', bg='Light Grey', fg='Black', font=("", 18))
        dfname.pack()

        Label(lb, bg='Light Grey').pack()

        dlname = Label(lb, text='Last Name', bg='Light Grey', fg='Black', font=("", 18))
        dlname.pack()

        Label(lb, bg='Light Grey').pack()

        ddob = Label(lb, text='Date of Birth', bg='Light Grey', fg='Black', font=("", 18))
        ddob.pack()

        Label(lb, bg='Light Grey').pack()

        dgender = Label(lb, text='Gender', bg='Light Grey', fg='Black', font=("", 18))
        dgender.pack()

        Label(lb, bg='Light Grey').pack()

        dadd = Label(lb, text='Address', bg='Light Grey', fg='Black', font=("", 18))
        dadd.pack()

        Label(lb, bg='Light Grey').pack()

        dcon = Label(lb, text='Contact', bg='Light Grey', fg='Black', font=("", 18))
        dcon.pack()

        Label(lb, bg='Light Grey').pack()

        dlicense = Label(lb, text='License No', bg='Light Grey', fg='Black', font=("", 18))
        dlicense.pack()

        Label(lb, bg='Light Grey').pack()

        dvehicle = Label(lb, text='Vehicle No', bg='Light Grey', fg='Black', font=("", 18))
        dvehicle.pack()

        Label(lb, bg='Light Grey').pack()

        demail = Label(lb, text='Email', bg='Light Grey', fg='Black', font=("", 18))
        demail.pack()

        Label(lb, bg='Light Grey').pack()

        dpass = Label(lb, text='Password', bg='Light Grey', fg='Black', font=("", 18))
        dpass.pack()

        Label(lb, bg='Light Grey').pack()

        txt = Frame(lbtx, bg='Light Grey')
        txt.pack(side='right', padx=40)

        self.__dfname = Entry(txt, bg='White', fg='Black')
        self.__dfname.pack()

        self.__dfnlb = Label(txt, bg='Light Grey')
        self.__dfnlb.pack()

        self.__dlname = Entry(txt, bg='White', fg='Black')
        self.__dlname.pack()

        self.__dlnlb = Label(txt, bg='Light Grey')
        self.__dlnlb.pack()

        date = Frame(txt, bg="Light Grey")
        date.pack()

        # using datetime module to find the current year
        x = datetime.now()
        y = x.year - 18
        z = x.year - 100
        yea = list(range(z, y))
        self.__yearvar = StringVar()
        year = Combobox(date, values=yea, textvariable=self.__yearvar, width=4, justify="left", state='readonly')
        year.set("Year")
        year.pack(side="left")

        mon = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
               "November", "December"]
        self.__monthvar = StringVar()
        self.month = Combobox(date, values=mon, textvariable=self.__monthvar, width=7, justify="left", state='readonly')
        self.month.set("Month")
        self.month.pack(side="left", padx=2)
        self.month.bind("<<ComboboxSelected>>", self.determine)

        self.__dayvar = StringVar()
        self.day = Combobox(date, values=[], textvariable=self.__dayvar, width=3, justify="left", state='readonly')
        self.day.set("Day")
        self.day.pack(side="left")

        self.__datelb = Label(txt, bg="Light Grey")
        self.__datelb.pack()

        self.__emt = Label(txt, bg='Light Grey', font=('', 1))
        self.__emt.pack()

        radiio = Frame(txt, bg="Light Grey")
        radiio.pack()

        self.__genval = StringVar()
        self.__genval.set('1')
        self.__male = Radiobutton(radiio, text="Male", variable=self.__genval, value="Male")
        self.__male.pack(side='left')
        self.__female = Radiobutton(radiio, text="Female", variable=self.__genval, value="Female")
        self.__female.pack(side='left', padx=10)
        self.__other = Radiobutton(radiio, text="Other", variable=self.__genval, value="Others")
        self.__other.pack(side='left')

        self.__genderlb = Label(txt, bg="Light Grey")
        self.__genderlb.pack()

        self.__emt2 = Label(txt, bg='Light Grey', font=('', 1))
        self.__emt2.pack()

        self.__dadd = Entry(txt, bg='White', fg='Black')
        self.__dadd.pack()

        self.__add = Label(txt, bg='Light Grey')
        self.__add.pack()

        self.__dcon = Entry(txt, bg='White', fg='Black')
        self.__dcon.pack()

        self.__con = Label(txt, bg='Light Grey')
        self.__con.pack()

        self.__dlicense = Entry(txt, bg='White', fg='Black')
        self.__dlicense.pack()

        self.__dlicenselb = Label(txt, bg='Light Grey')
        self.__dlicenselb.pack()

        self.__dvehiclevar = StringVar()
        self.__vehicleno = []
        record = self.__vmod.assigning()
        for data in record:
            vehivleno = data[1]
            self.__vehicleno.insert(0, vehivleno)
        self.__dvehicle = Combobox(txt, values=self.__vehicleno, textvariable=self.__dvehiclevar, width=18,
                                   justify='center', state='readonly')
        self.__dvehicle.set("Select Vehicle")
        self.__dvehicle.pack()

        self.__vehicle = Label(txt, bg='Light Grey')
        self.__vehicle.pack()

        self.__demail = Entry(txt, bg='White', fg='Black')
        self.__demail.pack()

        self.__demlb = Label(txt, bg='Light Grey')
        self.__demlb.pack()

        self.__dpass = Entry(txt, bg='White', fg='Black', show='*')
        self.__dpass.pack()

        self.__dpasslb = Label(txt, bg='Light Grey')
        self.__dpasslb.pack()

        btn = Frame(mainf, bg='Light Grey')
        btn.pack(expand=True)

        add = Button(btn, text='Add Driver', bg='Light Grey', fg='Black', bd=0, command=self.create)
        add.pack(side='left', padx=30, pady=10)

        cancel = Button(btn, text="Cancel", bg='Light Grey', fg="Black", bd=0, command=self.close)
        cancel.pack(side='right', padx=30, pady=10)

        self.__window.bind('<Return>', self.callcreate)

    # calling creating
    def callcreate(self, _):
        self.create()

    # determining the day to show
    def determine(self, _):
        if self.__yearvar.get() == 'Year':
            showinfo("Message", "Select a Year First")
            self.month.set("Month")
        match self.__monthvar.get():

            case "January":
                self.day.config(values=list(range(1, 32)))

            case "February":
                if int(self.__yearvar.get()) % 400 == 0:
                    self.day.config(values=list(range(1, 30)))

                else:
                    self.day.config(values=list(range(1, 29)))

            case "March":
                self.day.config(values=list(range(1, 32)))

            case "April":
                self.day.config(values=list(range(1, 31)))

            case "May":
                self.day.config(values=list(range(1, 32)))

            case "June":
                self.day.config(values=list(range(1, 31)))

            case "July":
                self.day.config(values=list(range(1, 32)))

            case "August":
                self.day.config(values=list(range(1, 32)))

            case "September":
                self.day.config(values=list(range(1, 31)))

            case "October":
                self.day.config(values=list(range(1, 32)))

            case "November":
                self.day.config(values=list(range(1, 31)))

            case "December":
                self.day.config(values=list(range(1, 32)))

    # validating and creating account
    def create(self):
        if self.validate():
            mod = RegistrationModel()
            if mod.double(self.__demail.get()):
                showinfo("Message", "Email Already Used")
            else:
                if self.__dmod.create():
                    if self.__vmod.assign(self.__dvehiclevar.get()):
                        showinfo("Message", "Account Created")
                        self.__window.destroy()

    # validating the data entered
    def validate(self):
        a = self.fn()
        b = self.ln()
        c = self.dob()
        d = self.gen()
        e = self.con()
        f = self.add()
        g = self.license()
        h = self.vehicle()
        i = self.em()
        j = self.pas()
        if a and b and c and d and e and f and g and h and i and j:
            return True

    def fn(self):
        if not self.__dfname.get():
            self.__dfnlb.config(text="First Name Can Not Be Empty.", font=("", 10), fg="Red")
            return False
        elif not re.match(self.__nmregex, self.__dfname.get()):
            self.__dfnlb.config(text="Invalid First Name", font=('', 10), fg='Red')
            return False
        else:
            self.__dfnlb.config(text="")
            self.__dmod.setfn(self.__dfname.get())
            return True

    def ln(self):
        if not self.__dlname.get():
            self.__dlnlb.config(text="Last Name Can Not Be Empty.", font=("", 10), fg="Red")
            return False
        elif not re.match(self.__nmregex, self.__dlname.get()):
            self.__dlnlb.config(text="Invalid Last Name", font=('', 10), fg='Red')
            return False
        else:
            self.__dlnlb.config(text="")
            self.__dmod.setln(self.__dlname.get())
            return True

    def dob(self):
        if self.__dayvar.get() == 'Day':
            self.__datelb.config(text="Select Date Of Birth.", font=("", 10), fg="Red")
            self.__emt.config(font=', 5')
            return False
        else:
            self.__datelb.config(text='')
            self.__emt.config(font=', 1')
            date = self.__yearvar.get() + "-" + self.__monthvar.get() + "-" + self.__dayvar.get()
            self.__dmod.setdate(date)
            return True

    def gen(self):
        if self.__genval.get() == '1':
            self.__genderlb.config(text="Select A Gender.", font=("", 10), fg="Red")
            self.__emt2.config(font=', 5')
            return False
        else:
            self.__genderlb.config(text='')
            self.__emt2.config(font=', 1')
            self.__dmod.setgen(self.__genval.get())
            return True

    def con(self):
        if not self.__dcon.get():
            self.__con.config(text="Contact Can Not Be Empty.", font=('', 10), fg='Red')
            return False
        elif not re.match(self.__conregx, self.__dcon.get()):
            self.__con.config(text="Invalid Contact", font=('', 10), fg='Red')
            return False
        else:
            self.__con.config(text="")
            self.__dmod.setcon(self.__dcon.get())
            return True

    def add(self):
        if not self.__dadd.get():
            self.__add.config(text='Address Can Not Be Empty.', font=('', 10), fg='Red')
            return False
        else:
            self.__add.config(text='')
            self.__dmod.setadd(self.__dadd.get())
            return True

    def license(self):
        if not self.__dlicense.get():
            self.__dlicenselb.config(text='License Can Not Be Empty.', font=("", 10), fg="Red")
            return False
        else:
            self.__dlicenselb.config(text='')
            self.__dmod.setlicense(self.__dlicense.get())
            return True

    def vehicle(self):
        if not self.__dvehiclevar.get():
            self.__vehicle.config(text='Select A Vehicle', font=("", 10), fg="Red")
            return False
        else:
            self.__vehicle.config(text='')
            vehicleid = self.__vmod.getid(self.__dvehiclevar.get())
            for data in vehicleid:
                vid = data[0]
                self.__dmod.setvehicle(vid)
                return True

    def em(self):
        email = self.__demail.get().lower()
        if not email:
            self.__demlb.config(text="Email Can Not Be Empty.", font=("", 10), fg="Red")
            return False
        elif not re.match(self.__emregex, email):
            self.__demlb.config(text="Enter Correct Email", font=("", 10), fg="Red")
            return False
        else:
            self.__demlb.config(text="")
            self.__dmod.setem(email)
            return True

    def pas(self):
        if not self.__dpass.get():
            self.__dpasslb.config(text="Password Can Not Be Empty.", font=("", 10), fg="Red")
            return False
        elif not re.match(self.__passregex, self.__dpass.get()):
            showinfo('Message', "Password must contain 8 letters, a capital letter, a small letter, a number and a "
                                "symbol")
            self.__dpasslb.config(text="Invalid Password", font=("", 10), fg="Red")
            return False
        else:
            self.__dpasslb.config(text="")
            self.__dmod.setpas(self.__dpass.get())
            return True

    # closing the top level if wrong click
    def close(self):
        self.__window.destroy()
