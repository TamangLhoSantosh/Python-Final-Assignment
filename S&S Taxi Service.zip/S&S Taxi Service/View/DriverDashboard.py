"""
    Module View
    This Is A Frontend Which User Sees And Input Data
"""
from datetime import date
# importing required modules
from tkinter import *
from tkinter import ttk
from tkinter.messagebox import askyesno, showinfo, showerror
from Model.TripModel import TripModel


# creating class Driver Home
# this is driver home
class DriverHome(ttk.Frame):

    # creating frame for admin home
    def __init__(self, window, controller, did):

        self.__did = did
        self.tripdata = None
        self.__window = window
        self.__window.deiconify()
        self.__tripmod = TripModel()
        self.__controller = controller
        super().__init__(self.__window)
        self.__window.geometry("1920x1080")
        self.__window.title("Admin Home")

        mainf = Frame(self.__window, bg="Light Grey")
        mainf.pack(expand=True, fill='both')

        topf = Frame(mainf, bg='Light Grey')
        topf.pack(side='top', fill='both', pady=20)

        self.logo = PhotoImage(file='Resource/logo.png')
        self.show = Label(topf, image=self.logo, bd=0)
        self.show.pack(side='left', padx=10)

        logout = Button(topf, text='Log Out', bg='Light Grey', fg='Black', bd=0, command=self.confirm)
        logout.pack(side='right', padx=10, pady=10)

        titlelb = Label(topf, text="Driver's Dashboard", bg='Light Grey', fg='Black', font=('', 30, "bold"))
        titlelb.pack(side='bottom', pady=10)

        self.table = Frame(mainf, bg='Light Grey')
        self.table.pack(expand=True, pady=40)

        style = ttk.Style(self.table)
        # set ttk theme to "clam" which support the field background option
        style.theme_use("clam")
        style.configure("Treeview", background="White", foreground="Black")

        self.scrollbar = Scrollbar(self.table)
        self.scrollbar.pack(side='right', fill='y')

        self.triptable()

    # creating table and adding
    def triptable(self):

        self.tripdata = ttk.Treeview(self.table, yscrollcommand=self.scrollbar.set, selectmode="extended")
        self.tripdata.pack()

        self.scrollbar.config(command=self.tripdata.yview)

        # defining columns
        self.tripdata["columns"] = ("Trip ID", "Customer Name", "Customer Contact", "Pick Up Location", "Destination",
                                    "No Of Passenger", "Departure Date", "Departure Time", "Distance", "Cost"
                                    , "Status")

        # formatting columns
        self.tripdata.column("#0", width=0, stretch=NO)
        self.tripdata.column("Trip ID", width=80, minwidth=50, anchor=W)
        self.tripdata.column("Customer Name", width=180, minwidth=90, anchor=W)
        self.tripdata.column("Customer Contact", width=180, minwidth=90, anchor=W)
        self.tripdata.column("Pick Up Location", width=180, minwidth=90, anchor=W)
        self.tripdata.column("Destination", width=180, minwidth=90, anchor=W)
        self.tripdata.column("No Of Passenger", width=100, minwidth=90, anchor=W)
        self.tripdata.column("Departure Date", width=100, minwidth=90, anchor=W)
        self.tripdata.column("Departure Time", width=100, minwidth=90, anchor=W)
        self.tripdata.column("Distance", width=100, minwidth=90, anchor=W)
        self.tripdata.column("Cost", width=100, minwidth=90, anchor=W)
        self.tripdata.column("Status", width=100, minwidth=90, anchor=W)

        # creating heading
        self.tripdata.heading("#0", text='Label')
        self.tripdata.heading("Trip ID", text="Trip Id")
        self.tripdata.heading("Customer Name", text="Customer Name")
        self.tripdata.heading("Customer Contact", text="Customer Contact")
        self.tripdata.heading("Pick Up Location", text="Pick Up Location")
        self.tripdata.heading("Destination", text="Destination")
        self.tripdata.heading("No Of Passenger", text="No Of Passenger")
        self.tripdata.heading("Departure Date", text="Departure Date")
        self.tripdata.heading("Departure Time", text="Departure Time")
        self.tripdata.heading("Distance", text="Distance")
        self.tripdata.heading("Cost", text="Cost")
        self.tripdata.heading("Status", text="Status")

        # reading data from table
        record = self.__tripmod.driverti(self.__did)
        if record:

            # inserting data into table
            for data in record:
                name = data[2] + " " + data[1]
                self.tripdata.insert("", index="end", values=(data[9], name, data[6], data[11], data[12], data[15],
                                                              data[13], data[14], data[16], data[17], data[18]))

            self.tripdata.bind('<Double-1>', self.data)

    # creating top level for specific trip
    def data(self, event):
        tripd = None
        try:
            if self.tripdata.selection()[0]:
                for data in self.tripdata.selection():
                    value = self.tripdata.item(data)
                    tripd = value['values']
                tp = Toplevel()

                # always top
                tp.transient(self.__window)
                tp.grab_set()

                self.details(tp, tripd)
        except Exception as e:
            showerror("Invalid", "Select A Data")
            print(e)

    def details(self, tp, tripd):
        top = tp
        top.geometry('670x380+350+235')
        top.title('Trip Details')

        mainf = Frame(top, bg='White')
        mainf.pack(fill='both', expand=True)

        titlef = Frame(mainf, bg='White')
        titlef.pack(pady=10)

        title = Label(titlef, text='Trip Detail', bg='White', fg='Black', font=('EB Garamond', 25, 'bold'))
        title.pack(anchor='center')

        lbdataf = Frame(mainf, bg='White')
        lbdataf.pack(pady=10)

        leftf = Frame(lbdataf, bg='White')
        leftf.pack(side='left', padx=10, pady=10)

        leftlbf = Frame(leftf, bg='White')
        leftlbf.pack(side='left', padx=10)

        namelb = Label(leftlbf, text='Customer Name :', bg='White', fg='Black', font=('Crimson Text', 18))
        namelb.pack(pady=10)

        pickloc = Label(leftlbf, text='Pickup        : ', bg='White', fg='Black', font=('Crimson Text', 18))
        pickloc.pack(pady=10)

        datelb = Label(leftlbf, text='Date          : ', bg='White', fg='Black', font=('Crimson Text', 18))
        datelb.pack(pady=10)

        passengerlb = Label(leftlbf, text='Passenger     : ', bg='White', fg='Black', font=('Crimson Text', 18))
        passengerlb.pack(pady=10)

        costlb = Label(leftlbf, text="Cost          : ", bg='White', fg='Black', font=('Crimson Text', 18))
        costlb.pack(pady=10)

        leftdataf = Frame(leftf, bg='White')
        leftdataf.pack(side='right', padx=10)

        namedata = Label(leftdataf, text=tripd[1], bg='White', fg='Black', font=('Crimson Text', 16))
        namedata.pack(pady=10)

        picklocdata = Label(leftdataf, text=tripd[3], bg='White', fg='Black', font=('Crimson Text', 16))
        picklocdata.pack(pady=10)

        datedata = Label(leftdataf, text=tripd[6], bg='White', fg='Black', font=('Crimson Text', 16))
        datedata.pack(pady=10)

        passegerdata = Label(leftdataf, text=tripd[5], bg='White', fg='Black', font=('Crimson Text', 16))
        passegerdata.pack(pady=10)

        costdata = Label(leftdataf, text=tripd[9], bg='White', fg='Black', font=('Crimson Text', 16))
        costdata.pack(pady=10)

        rightf = Frame(lbdataf, bg='White')
        rightf.pack(side='right', padx=10, pady=10)

        rightlbf = Frame(rightf, bg='White')
        rightlbf.pack(side='left', padx=10)

        conlb = Label(rightlbf, text="Customer Number : ", bg='White', fg='Black', font=('Crimson Text', 18))
        conlb.pack(pady=10)

        droploc = Label(rightlbf, text='Destination     : ', bg='White', fg='Black', font=('Crimson Text', 18))
        droploc.pack(pady=10)

        timelb = Label(rightlbf, text='Time            : ', bg='White', fg='Black', font=('Crimson Text', 18))
        timelb.pack(pady=10)

        distlb = Label(rightlbf, text="Distance        : ", bg='White', fg='Black', font=('Crimson Text', 18))
        distlb.pack(pady=10)

        statuslb = Label(rightlbf, text='Status         : ', bg='White', fg='Black', font=('Crimson Text', 18))
        statuslb.pack(pady=10)

        rightdataf = Frame(rightf, bg='White')
        rightdataf.pack(side='right', padx=10)

        condata = Label(rightdataf, text=tripd[2], bg='White', fg='Black', font=('Crimson Text', 16))
        condata.pack(pady=10)

        droplocdata = Label(rightdataf, text=tripd[4], bg='White', fg='Black', font=('Crimson Text', 16))
        droplocdata.pack(pady=10)

        timedata = Label(rightdataf, text=tripd[7], bg='White', fg='Black', font=('Crimson Text', 16))
        timedata.pack(pady=10)

        distdata = Label(rightdataf, text=tripd[8], bg='White', fg='Black', font=('Crimson Text', 16))
        distdata.pack(pady=10)

        statusdata = Label(rightdataf, text=tripd[10], bg='White', fg='Black', font=('Crimson Text', 16))
        statusdata.pack(pady=10)

        btnf = Frame(mainf, bg='White')
        btnf.pack(pady=10)

        start = None
        complete = None
        now = date.today()

        if tripd[10] == "Confirmed":
            if complete:
                complete.destroy()
            start = Button(btnf, text='Start The Trip', bg='Light Grey', fg="Black", bd=0, command=lambda: startrip())
            start.pack()
        elif tripd[10] == "Started":
            if start:
                start.destroy()
            complete = Button(btnf, text='Complete', bg='Light Grey', fg='Black', bd=0, command=lambda: completetrip())
            complete.pack()
        else:
            if complete:
                complete.destroy()
            if start:
                start.destroy()

        # starting trip
        def startrip():
            if tripd[6] == now:
                if self.__tripmod.startrip(tripd[0]):
                    showinfo("Message", "Trip Started")
                    top.destroy()
                    self.tripdata.destroy()
                    self.triptable()
            else:
                showerror("Invalid", "Trip Can Not Be Started Now.")

        def completetrip():
            if self.__tripmod.completetrip(tripd[0]):
                showinfo("Message", "Trip Completed")
                top.destroy()
                self.tripdata.destroy()
                self.triptable()

    # confirming log out
    def confirm(self):
        ans = askyesno("Conformation", "Are You Sure You Want To Log Out?")
        if ans:
            self.__controller.log()
