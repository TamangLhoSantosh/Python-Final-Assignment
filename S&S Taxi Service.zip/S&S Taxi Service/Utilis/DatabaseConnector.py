"""
    Module Utilis
    This Connects With The Database
"""

# importing required modules
import psycopg2 as db
from psycopg2 import OperationalError


class DatabaseConnection:
    __conn = None
    __cur = None

    def __init__(self):

        # loading details of database
        self.host = 'localhost'
        self.db = 'xic'
        self.user = 'xic'
        self.port = 5432

        # connect to database
        self.__connect()
        self.__dbcur = DatabaseConnection.__cur
        self.__dbconn = DatabaseConnection.__conn

    def __connect(self):
        try:
            if DatabaseConnection.__conn is None:
                DatabaseConnection.__conn = db.connect(database=self.db, user=self.user,
                                                       host=self.host, port=self.port)
                DatabaseConnection.__conn.autocommit = True
                DatabaseConnection.__cur = DatabaseConnection.__conn.cursor()
        except OperationalError as e:
            raise e

    @property
    def cursor(self):
        return self.__dbcur

    def close(self):
        self.__dbconn.close()
