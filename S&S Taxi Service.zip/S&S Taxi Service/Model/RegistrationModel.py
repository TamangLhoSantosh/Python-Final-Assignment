# importing required modules
from Utilis.DatabaseConnector import DatabaseConnection


# declaring model class
class RegistrationModel:

    def __init__(self):

        # declaring variables tobe used
        self.__fn = None
        self.__ln = None
        self.__date = None
        self.__gen = None
        self.__add = None
        self.__con = None
        self.__em = None
        self.__pas = None
        self.__cur = DatabaseConnection().cursor

    # getters for customer
    def getfn(self):
        return self.__fn

    def getln(self):
        return self.__ln

    def getdate(self):
        return self.__date

    def getgen(self):
        return self.__gen

    def getadd(self):
        return self.__add

    def getcon(self):
        return self.__con

    def getem(self):
        return self.__em

    def getpas(self):
        return self.__pas

    # setter for customer
    def setfn(self, fn):
        self.__fn = fn

    def setln(self, ln):
        self.__ln = ln

    def setdate(self, date):
        self.__date = date

    def setgen(self, gen):
        self.__gen = gen

    def setadd(self, add):
        self.__add = add

    def setcon(self, con):
        self.__con = con

    def setem(self, em):
        self.__em = em

    def setpas(self, pas):
        self.__pas = pas

    # creating account for customer
    def create(self):
        query = """INSERT INTO CUSTOMER(FIRSTNAME, LASTNAME, DOB, GENDER, ADDRESS, CONTACT, EMAIL, PASS) VALUES(
        %s, %s, %s, %s, %s, %s, %s, %s)"""
        values = (self.getfn(), self.getln(), self.getdate(), self.getgen(), self.getadd(), self.getcon(), self.getem(),
                  self.getpas())
        self.__cur.execute(query, values)
        return True

    # checking for same email
    def double(self, email):
        query = """SELECT * FROM CUSTOMER WHERE EMAIL=%s"""
        self.__cur.execute(query, [email])
        record = self.__cur.fetchall()
        if record:
            return True

        query = """SELECT * FROM STAFF WHERE EMAIL=%s"""
        self.__cur.execute(query, [email])
        record = self.__cur.fetchall()
        if record:
            return True

        query = """SELECT * FROM DRIVER WHERE EMAIL=%s"""
        self.__cur.execute(query, [email])
        record = self.__cur.fetchall()
        if record:
            return True
