# importing required modules
from datetime import date
from Utilis.DatabaseConnector import DatabaseConnection


# declaring vehicle model class
class VehicleModel:

    def __init__(self):
        self.__vehicleid = None
        self.__vehicleno = None
        self.__vehicletype = None
        self.__vehiclemodel = None
        self.__vehicledate = None
        self.__description = None
        self.__vehiclestatus = None
        self.__cur = DatabaseConnection().cursor

    # getters
    def getvehicleid(self):
        return self.__vehicleid

    def getvehicleno(self):
        return self.__vehicleno

    def getvehicletype(self):
        return self.__vehicletype

    def getvehiclemodel(self):
        return self.__vehiclemodel

    def getvehicledate(self):
        return self.__vehicledate

    def getdescription(self):
        return self.__description

    def getstatus(self):
        return self.__vehiclestatus

    # setter
    def setvehicleid(self, vid):
        self.__vehicleid = vid

    def setvehicleno(self, vno):
        self.__vehicleno = vno

    def setvehicletype(self, vtype):
        self.__vehicletype = vtype

    def setvehiclemodel(self, mod):
        self.__vehiclemodel = mod

    def setvehicledate(self, date):
        self.__vehicledate = date

    def setdescription(self, des):
        self.__description = des

    def setstatus(self, stat):
        self.__vehiclestatus = stat

    # inserting data into vehicle
    def addV(self):
        query = """INSERT INTO VEHICLE(VEHICLENO, VEHICLETYPE, VEHICLEMODEL, VEHICLEDATE, DESCRIPTION, STATUS)
        VALUES(%s, %s, %s, %s, %s, %s)"""
        now = date.today()
        values = (self.getvehicleno(), self.getvehicletype(), self.getvehiclemodel(), now, self.getdescription(),
                  "Not Assigned")
        print(values)
        self.__cur.execute(query, values)
        return True

    def allvehicle(self):
        query = """SELECT * FROM VEHICLE"""
        self.__cur.execute(query)
        record = self.__cur.fetchall()
        if record:
            return record

    # checking for double
    def double(self, vecno):
        query = """SELECT * FROM VEHICLE WHERE VEHICLENO=%s ORDER BY VEHICLEID"""
        self.__cur.execute(query, [vecno])
        record = self.__cur.fetchall()
        if record:
            return True

    # for assigning
    def assigning(self):
        query = """SELECT VEHICLEID FROM VEHICLE WHERE STATUS=%s"""
        self.__cur.execute(query, ["Not Assigned"])
        record = self.__cur.fetchall()
        return record

    # deleting vehicle details
    def delete(self):
        query = """DELETE FROM VEHICLE WHERE VEHICLEID=%s"""
        self.__cur.execute(query, [self.getvehicleid()])
        return True
