# importing required modules
from Utilis.DatabaseConnector import DatabaseConnection


# declaring model class
class StaffModel:
    def __init__(self):
        self.__stid = None
        self.__fn = None
        self.__ln = None
        self.__date = None
        self.__gen = None
        self.__add = None
        self.__con = None
        self.__em = None
        self.__pas = None
        self.__cur = DatabaseConnection().cursor

    # getters for customer
    def getstid(self):
        return self.__stid

    def getfn(self):
        return self.__fn

    def getln(self):
        return self.__ln

    def getdate(self):
        return self.__date

    def getgen(self):
        return self.__gen

    def getadd(self):
        return self.__add

    def getcon(self):
        return self.__con

    def getem(self):
        return self.__em

    def getpas(self):
        return self.__pas

    # setter for customer
    def setstid(self, stid):
        self.__stid = stid

    def setfn(self, fn):
        self.__fn = fn

    def setln(self, ln):
        self.__ln = ln

    def setdate(self, date):
        self.__date = date

    def setgen(self, gen):
        self.__gen = gen

    def setadd(self, add):
        self.__add = add

    def setcon(self, con):
        self.__con = con

    def setem(self, em):
        self.__em = em

    def setpas(self, pas):
        self.__pas = pas

    # login as staff
    def staff(self):
        query = """SELECT * FROM ADMIN WHERE EMAIL=%s AND PASS=%s"""
        value = (self.getem(), self.getpas())
        self.__cur.execute(query, value)
        record = self.__cur.fetchall()
        if record:
            return record

    # creating account for staff
    def create(self):
        query = """INSERT INTO STAFF(FIRSTNAME, LASTNAME, DOB, GENDER, ADDRESS, CONTACT, EMAIL, PASS) 
        VALUES(%s, %s, %s, %s, %s, %s, %s, %s)"""
        values = (self.getfn(), self.getln(), self.getdate(), self.getgen(), self.getadd(), self.getcon(),
                  self.getem(), self.getpas())
        self.__cur.execute(query, values)
        return True

    # showing all staff detail
    def allstaff(self):
        query = """SELECT * FROM STAFF ORDER BY STAFFD"""
        self.__cur.execute(query)
        record = self.__cur.fetchall()
        if record:
            return record

    # deleting staff details
    def delete(self, stid):
        query = """DELETE FROM STAFF WHERE STAFFID=%s"""
        self.__cur.execute(query, [stid])
        return True
