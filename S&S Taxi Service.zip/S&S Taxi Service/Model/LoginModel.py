"""
    Module Model
    This Connects With The Database Connector
"""

# importing required modules
from Utilis.DatabaseConnector import DatabaseConnection


# declaring model class
class LoginModel:

    def __init__(self):
        self.__em = None
        self.__pas = None
        self.__id = None
        self.__cur = DatabaseConnection().cursor

    # gettter
    def getem(self):
        return self.__em

    def getpas(self):
        return self.__pas

    # setter
    def setem(self, em):
        self.__em = em

    def setpas(self, pas):
        self.__pas = pas

    # login as customer
    def cust(self):
        query = """SELECT * FROM CUSTOMER WHERE EMAIL=%s AND PASS=%s"""
        value = (self.getem(), self.getpas())
        self.__cur.execute(query, value)
        record = self.__cur.fetchall()
        if record:
            return record

    # login as driver
    def driver(self):
        query = """SELECT * FROM DRIVER WHERE EMAIL=%s AND PASS=%s"""
        value = (self.getem(), self.getpas())
        self.__cur.execute(query, value)
        record = self.__cur.fetchall()
        if record:
            return record
