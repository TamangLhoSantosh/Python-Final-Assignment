"""
    Module Model
    This Connects With The Database Connector
"""

# importing required modules
from Utilis.DatabaseConnector import DatabaseConnection


# declaring model class
class CustomerModel:

    def __init__(self):

        # declaring variables to be used
        self.__custid = None
        self.__fn = None
        self.__ln = None
        self.__date = None
        self.__gen = None
        self.__add = None
        self.__con = None
        self.__em = None
        self.__pas = None
        self.__cur = DatabaseConnection().cursor

    # getters for customer
    def getcustid(self):
        return self.__custid

    def getfn(self):
        return self.__fn

    def getln(self):
        return self.__ln

    def getdate(self):
        return self.__date

    def getgen(self):
        return self.__gen

    def getadd(self):
        return self.__add

    def getcon(self):
        return self.__con

    def getem(self):
        return self.__em

    def getpas(self):
        return self.__pas

    # setter for customer
    def setcustid(self, id):
        self.__custid = id

    def setfn(self, fn):
        self.__fn = fn

    def setln(self, ln):
        self.__ln = ln

    def setdate(self, date):
        self.__date = date

    def setgen(self, gen):
        self.__gen = gen

    def setadd(self, add):
        self.__add = add

    def setcon(self, con):
        self.__con = con

    def setem(self, em):
        self.__em = em

    def setpas(self, pas):
        self.__pas = pas

    # select all customers
    def allcust(self):
        query = """SELECT * FROM CUSTOMER"""
        self.__cur.execute(query)
        record = self.__cur.fetchall()
        if record:
            return record

    # getting details
    def details(self, custid):
        query = """SELECT * FROM CUSTOMER WHERE CUSTID=%s ORDER BY CUSTID"""
        self.__cur.execute(query, [custid])
        record = self.__cur.fetchall()
        if record:
            return record

    # updating details
    def updatedetatil(self, custid):
        query = """UPDATE CUSTOMER SET FIRSTNAME=%s, LASTNAME=%s, ADDRESS=%s, CONTACT=%s WHERE CUSTID=%s"""
        values = (self.getfn(), self.getln(), self.getadd(), self.getcon(), custid)
        self.__cur.execute(query, values)
        return True

    # searching for customer
    def search(self, name, add):
        query = """SELECT * FROM CUSTOMER WHERE CONCAT(FIRSTNAME,' ', LASTNAME) ILIKE CONCAT('%%',%s,'%%') AND 
        ADDRESS ILIKE CONCAT('%%',%s,'%%')"""
        value = (name, add)
        self.__cur.execute(query, value)
        record = self.__cur.fetchall()
        if record:
            return record

    # deleting one customer
    def delete(self, custid):
        query = """DELETE FROM CUSTOMER WHERE CUSTID=%s"""
        self.__cur.execute(query, [custid])
        return True
