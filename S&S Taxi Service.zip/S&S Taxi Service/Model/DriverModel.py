# importing required modules
from Utilis.DatabaseConnector import DatabaseConnection


# declaring model class
class DriverModel:

    def __init__(self):
        self.__drid = None
        self.__fn = None
        self.__ln = None
        self.__date = None
        self.__gen = None
        self.__add = None
        self.__con = None
        self.__license = None
        self.__vehicle = None
        self.__em = None
        self.__pas = None
        self.__cur = DatabaseConnection().cursor

    # getters for customer
    def getdrid(self):
        return self.__drid

    def getfn(self):
        return self.__fn

    def getln(self):
        return self.__ln

    def getdate(self):
        return self.__date

    def getgen(self):
        return self.__gen

    def getadd(self):
        return self.__add

    def getcon(self):
        return self.__con

    def getlicense(self):
        return self.__license

    def getvehicle(self):
        return self.__vehicle

    def getem(self):
        return self.__em

    def getpas(self):
        return self.__pas

    # setter for customer
    def setdrid(self, did):
        self.__drid = did

    def setfn(self, fn):
        self.__fn = fn

    def setln(self, ln):
        self.__ln = ln

    def setdate(self, date):
        self.__date = date

    def setgen(self, gen):
        self.__gen = gen

    def setadd(self, add):
        self.__add = add

    def setcon(self, con):
        self.__con = con

    def setlicense(self, no):
        self.__license = no

    def setvehicle(self, id):
        self.__vehicle = id

    def setem(self, em):
        self.__em = em

    def setpas(self, pas):
        self.__pas = pas

    # creating account for Driver
    def create(self):
        query = """INSERT INTO DRIVER(FIRSTNAME, LASTNAME, DOB, GENDER, ADDRESS, CONTACT, LICENSENO, EMAIL, PASS, 
        VEHICLEID) 
        VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
        values = (self.getfn(), self.getln(), self.getdate(), self.getgen(), self.getadd(), self.getcon(),
                  self.getlicense(), self.getem(), self.getpas(), self.getvehicle())
        self.__cur.execute(query, values)
        return True

    # selecting all driver
    def alldriver(self):
        query = """SELECT * FROM DRIVER ORDER BY DRIVERID"""
        self.__cur.execute(query)
        record = self.__cur.fetchall()
        if record:
            return record

    # selecting all driver who are empty on particular day
    def emptydriver(self, when):
        query = """SELECT * FROM DRIVER WHERE DRIVERID NOT IN (SELECT DRIVERID FROM TRIP WHERE TRIPDATE=%s AND 
        DRIVERID IS NOT NULL ORDER BY DRIVERID)"""
        self.__cur.execute(query, [when])
        record = self.__cur.fetchall()
        if record:
            return record

    # returning id from name
    def getid(self, name):
        query = """SELECT DRIVERID FROM DRIVER WHERE CONCAT(LASTNAME,' ', FIRSTNAME) ILIKE CONCAT('%%',%s,'%%')"""
        self.__cur.execute(query, [name])
        record = self.__cur.fetchall()
        if record:
            return record

    # deleting the driver details
    def delete(self):
        query = """DELETE FROM DRIVER WHERE DRIVERID=%s"""
        self.__cur.execute(query, [self.getdrid()])
        return True
