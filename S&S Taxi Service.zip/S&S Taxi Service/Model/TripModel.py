"""
    Module Model
    This Connects With The Database Connector
"""

# importing required modules
from Utilis.DatabaseConnector import DatabaseConnection
from datetime import date


# declaring class trip model
class TripModel:

    def __init__(self):
        self.__custid = None
        self.__pickloc = None
        self.__droploc = None
        self.__tripdate = None
        self.__picktime = None
        self.__passno = None
        self.__cost = None
        self.__status = None
        self.__distance = None
        self.__cur = DatabaseConnection().cursor

    # getters
    def getcustid(self):
        return self.__custid

    def getpickloc(self):
        return self.__pickloc

    def getdroploc(self):
        return self.__droploc

    def gettripdate(self):
        return self.__tripdate

    def getpicktime(self):
        return self.__picktime

    def getpassno(self):
        return self.__passno

    def getcost(self):
        return self.__cost

    def getstatus(self):
        return self.__status

    def getdistance(self):
        return self.__distance

    # setter
    def setcustid(self, custid):
        self.__custid = custid

    def setpickloc(self, pickloc):
        self.__pickloc = pickloc

    def setdroploc(self, droploc):
        self.__droploc = droploc

    def settripdate(self, tripdate):
        self.__tripdate = tripdate

    def setpicktime(self, picktime):
        self.__picktime = picktime

    def setpassno(self, passno):
        self.__passno = passno

    def setcost(self, cost):
        self.__cost = cost

    def setdistance(self, dis):
        self.__distance = dis

    # book a trip
    def booktrip(self):
        now = str(date.today())
        query = """INSERT INTO TRIP(CUSTID, BOOKINGDATE, PICKUPLOC, DROPLOC, TRIPDATE, PICKUPTIME, NOOFPASS, TOTALCOST,
        TRIPSTATUS, PAYMENT_METHOD, PAYMENT_STATUS, DISTANCE) VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
        values = (self.getcustid(), now, self.getpickloc(), self.getdroploc(), self.gettripdate(), self.getpicktime(),
                  self.getpassno(), self.getcost(), "Pending", "Cash", "Pending", self.getdistance())
        self.__cur.execute(query, values)
        return True

    # showing trip of a customer
    def custrip(self, custid):
        query = """SELECT * FROM TRIP WHERE CUSTID=%s ORDER BY TRIPDATE"""
        self.__cur.execute(query, [custid])
        record = self.__cur.fetchall()
        if record:
            return record

    # showing all trip assigned to a driver with customer details
    def driverti(self, did):
        query = """SELECT * FROM CUSTOMER C JOIN TRIP T ON T.CUSTID=C.CUSTID WHERE T.DRIVERID=%s ORDER BY T.TRIPDATE"""
        self.__cur.execute(query, [did])
        record = self.__cur.fetchall()
        if record:
            return record

    # starting the trip
    def startrip(self, tripid):
        query = """UPDATE TRIP SET TRIPSTATUS=%s WHERE TRIPID=%s"""
        values = ("Started", tripid)
        self.__cur.execute(query, values)
        return True

    # marking trip completed
    def completetrip(self, tripid):
        query = """UPDATE TRIP SET TRIPSTATUS=%s, PAYMENT_STATUS=%s WHERE TRIPID=%s"""
        values = ("Completed", "Paid", tripid)
        self.__cur.execute(query, values)
        return True

    # showing all trips
    def alltrip(self):
        query = """SELECT * FROM TRIP T JOIN CUSTOMER C ON T.CUSTID=C.CUSTID ORDER BY T.TRIPDATE"""
        self.__cur.execute(query)
        record = self.__cur.fetchall()
        if record:
            return record

    # showing trip detail where trip status is cancelled or pending
    def tripdetail(self, tripid):
        query = """SELECT * FROM TRIP WHERE TRIPID=%s ORDER BY TRIPDATE"""
        self.__cur.execute(query, [tripid])
        record = self.__cur.fetchall()
        if record:
            return record

    # showing all details related to trip where status is not cancelled or pending
    def tripdetails(self, tripid):
        query = """SELECT * FROM TRIP T JOIN DRIVER D ON D.DRIVERID=T.DRIVERID JOIN VEHICLE V ON 
        D.VEHICLEID=V.VEHICLEID WHERE T.TRIPID=%s ORDER BY T.TRIPDATE"""
        self.__cur.execute(query, [tripid])
        record = self.__cur.fetchall()
        if record:
            return record

    # showing all pending trips
    def pendingtrip(self):
        query = """SELECT * FROM TRIP T JOIN CUSTOMER C ON T.CUSTID=C.CUSTID WHERE TRIPSTATUS=%s ORDER BY T.TRIPDATE"""
        self.__cur.execute(query, ['Pending'])
        record = self.__cur.fetchall()
        if record:
            return record

    # assign driver and making trip status confirmed
    def assigndr(self, stid, did, tpid):
        query = """UPDATE TRIP SET STAFFID=%s, DRIVERID=%s, TRIPSTATUS=%s WHERE TRIPID=%s"""
        values = (stid, did, "Confirmed", tpid)
        self.__cur.execute(query, values)
        return True

    # showing all today's trip
    def todaytrip(self):
        now = date.today()
        query = """SELECT * FROM TRIP T JOIN CUSTOMER C ON T.CUSTID=C.CUSTID WHERE TRIPDATE=%s ORDER BY T.TRIPDATE"""
        self.__cur.execute(query, [str(now)])
        record = self.__cur.fetchall()
        if record:
            return record

    # cancelling selected trip
    def canceltrip(self, tripid):
        query = """UPDATE TRIP SET TRIPSTATUS=%s WHERE TRIPID=%s"""
        values = ("Cancelled", tripid)
        self.__cur.execute(query, values)
        return True

    # deleting selected trip
    def deletetrip(self, tripid):
        query = """DELETE FROM TRIP WHERE TRIPID=%s"""
        self.__cur.execute(query, [tripid])
        return True
