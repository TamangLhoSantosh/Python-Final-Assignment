"""
    This is the main file that starts the program.
    Everything starts from here.
"""

# importing required modules
from View.Basewindow import Basewindow
from Controller.Controller import Controller


# running the code from here
# START POINT
if __name__ == '__main__':
    root = Basewindow()
    log = Controller(root)
    root.mainloop()
