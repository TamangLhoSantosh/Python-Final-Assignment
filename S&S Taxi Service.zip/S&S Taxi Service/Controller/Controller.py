# importing required modules
from tkinter import Toplevel
from View.LoginPage import LoginPage
from View.StaffLogin import StaffLogin
from View.StaffDashboard import StaffHome
from View.DriverDashboard import DriverHome
from View.RegistrationPage import RegistrationPage
from View.CustDashboard import CustDashboard, BookingPage


# creating class controller
class Controller:

    # creating login page
    def __init__(self, root):
        self.__root = root
        self.__root.withdraw()
        self.__clear_root()
        lg = Toplevel()
        log = LoginPage(lg, self)

    # creating registration page
    def reg(self):
        self.__clear_root()
        rg = Toplevel()
        reg = RegistrationPage(rg, self)

    # creating login page
    def log(self):
        lg = Controller(self.__root)

    # creating customer home page
    def custlog(self, custid):
        self.__clear_root()
        dash = CustDashboard(self.__root, self, custid)

    # creating profile page
    def book(self, custid):
        self.__clear_root()
        bk = BookingPage(self.__root, self, custid)

    # creating admin login page
    def admin(self):
        self.__clear_root()
        add = Toplevel()
        ad = StaffLogin(add, self)

    # creating admin home page
    def admindash(self, stid):
        self.__clear_root()
        addh = StaffHome(self.__root, self, stid)

    # creating admin home page
    def driverdash(self, did):
        self.__clear_root()
        ddh = DriverHome(self.__root, self, did)

    # clearing the tk window
    def __clear_root(self):
        for child in self.__root.winfo_children():
            child.destroy()
